app_name = "restaurant_ops"
app_title = "Restaurant Operations"
app_publisher = "Roshdy IT"
app_description = "Unified Restaurant Operations & Contact Center System — v30 clean install"
app_email = "it@roshdy.com"
app_license = "mit"

use_json_request_body = True
require_type_annotated_api_methods = True
export_python_type_annotations = True

home_page = "home"

role_home_page = {
    "Call Center Admin": "admin-desk",
    "System Manager": "admin-desk",
    "Break Admin": "admin-desk",
    "Complaint_Quality_User": "quality-desk",
    "Complaint_Finance_User": "admin-desk",
    "Restaurant Agent": "home",
}

on_login = ["restaurant_ops.api.login_redirect.on_login"]
app_include_js = ["/assets/restaurant_ops/js/desk_redirect.js"]

website_route_rules = [
    {"from_route": "/choose", "to_route": "/home"},
    {"from_route": "/desk", "to_route": "/home"},
]

scheduler_events = {
    "cron": {
        "*/2 * * * *": ["restaurant_ops.api.sync_calls.sync_recent_calls"],
        "30 5 * * *": ["restaurant_ops.api.email_report.send_daily_shift_report"],
    }
}
