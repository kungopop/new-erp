import frappe

def _target_for(user: str) -> str:
    if not user or user == "Guest": return "/login"
    if user == "Administrator": return "/app"
    roles = frappe.get_roles(user)
    if "Complaint_Quality_User" in roles and "Call Center Admin" not in roles and "System Manager" not in roles:
        return "/quality-desk"
    if any(r in roles for r in {"Call Center Admin", "System Manager", "Break Admin", "Complaint_Finance_User"}):
        return "/admin-desk"
    if "Restaurant Agent" in roles:
        ext = frappe.db.get_value("Extension Session", {"user": user, "session_status": "active"}, "extension")
        return "/agent-desk" if ext else "/select-extension"
    return "/login?msg=no_role"

def on_login(login_manager):
    try:
        frappe.local.response["home_page"] = _target_for(frappe.session.user)
    except Exception:
        frappe.local.response["home_page"] = "/login"

@frappe.whitelist(allow_guest=True)
def get_user_redirect() -> dict:
    try:
        return {"redirect": _target_for(frappe.session.user)}
    except Exception:
        return {"redirect": "/login"}
