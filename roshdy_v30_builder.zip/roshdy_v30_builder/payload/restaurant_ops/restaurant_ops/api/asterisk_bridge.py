import frappe
import subprocess
import socket
import time
from frappe.utils import get_datetime

ASTERISK_DB_NAME_DEFAULT = "asteriskcdrdb"
MYSQL_TIMEOUT = 12
MISSED_THRESHOLD_SEC = 30

def _conf(key: str, default=None):
    return frappe.conf.get(key) or default

def _settings_host():
    try:
        s = frappe.get_single("Call Center Settings")
        return s.asterisk_host or _conf("asterisk_host", "10.11.1.253")
    except Exception:
        return _conf("asterisk_host", "10.11.1.253")

def _db_credentials():
    return [
        (_conf("asterisk_db_user", "asteriskuser"), _conf("asterisk_db_password", "")),
        (_conf("asterisk_db_alt_user", "besho"), _conf("asterisk_db_alt_password", "")),
    ]

def _db_name():
    return _conf("asterisk_db_name", ASTERISK_DB_NAME_DEFAULT)

@frappe.whitelist(allow_guest=False)
def run_full_system_diagnostics() -> dict:
    host = _settings_host()
    ami_port = int(_conf("asterisk_ami_port", 5038))
    report = {
        "timestamp": str(frappe.utils.now_datetime()), "host": host,
        "network_tcp_3306": {"status": "untested", "latency_ms": 0, "error": None},
        "network_tcp_5038": {"status": "untested", "latency_ms": 0, "error": None},
        "mysql_pymysql_check": {"status": "untested", "records": 0, "error": None},
        "mysql_cli_check": {"status": "untested", "error": None},
        "ami_socket_check": {"status": "untested", "response_sample": "", "error": None},
        "summary": ""
    }
    for port_key, port in [("network_tcp_3306", 3306), ("network_tcp_5038", ami_port)]:
        t0 = time.time()
        try:
            s = socket.create_connection((host, port), timeout=3.0)
            report[port_key]["latency_ms"] = round((time.time()-t0)*1000, 2)
            report[port_key]["status"] = "OK"; s.close()
        except Exception as e:
            report[port_key]["status"] = "FAILED"; report[port_key]["error"] = str(e)
    try:
        rows, err = query_asterisk_cdr_with_error("SELECT COUNT(*) as cnt FROM cdr;")
        if rows:
            report["mysql_pymysql_check"]["status"] = "OK"
            report["mysql_pymysql_check"]["records"] = int(rows[0].get("cnt") or 0)
        else:
            report["mysql_pymysql_check"]["status"] = "FAILED"; report["mysql_pymysql_check"]["error"] = err
    except Exception as e:
        report["mysql_pymysql_check"]["status"] = "FAILED"; report["mysql_pymysql_check"]["error"] = str(e)
    try:
        user, pwd = _db_credentials()[0]
        r = subprocess.run(['mysql','-h',host,'-u',user,f'-p{pwd}',_db_name(),'--batch','--raw','-e','SELECT COUNT(*) FROM cdr;'], capture_output=True, text=True, timeout=8)
        report["mysql_cli_check"]["status"] = "OK" if r.returncode == 0 else "FAILED"
        if r.returncode != 0: report["mysql_cli_check"]["error"] = r.stderr.strip()
    except Exception as e:
        report["mysql_cli_check"]["status"] = "FAILED"; report["mysql_cli_check"]["error"] = str(e)
    try:
        s = socket.create_connection((host, ami_port), timeout=4.0)
        ami_user = _conf("asterisk_ami_user", "phpadmin"); ami_secret = _conf("asterisk_ami_secret", "")
        s.sendall(f"Action: Login\r\nUsername: {ami_user}\r\nSecret: {ami_secret}\r\n\r\n".encode())
        resp = s.recv(1024).decode(errors="ignore")
        try: s.sendall(b"Action: Logoff\r\n\r\n"); s.shutdown(socket.SHUT_RDWR)
        except Exception: pass
        s.close()
        report["ami_socket_check"]["status"] = "OK" if ("Success" in resp or "Asterisk" in resp) else "WARNING"
        report["ami_socket_check"]["response_sample"] = resp[:200].replace("\r\n", " | ")
    except Exception as e:
        report["ami_socket_check"]["status"] = "FAILED"; report["ami_socket_check"]["error"] = str(e)
    if report["network_tcp_3306"]["status"] == "FAILED":
        report["summary"] = f"🔴 بورت 3306 مقفول أو الشبكة تمنع الوصول إلى {host}: {report['network_tcp_3306']['error']}"
    elif report["mysql_pymysql_check"]["status"] == "FAILED":
        report["summary"] = f"🔴 الشبكة سليمة لكن MySQL رفض الدخول: {report['mysql_pymysql_check']['error']}"
    elif report["ami_socket_check"]["status"] == "FAILED":
        report["summary"] = f"🔴 قاعدة CDR سليمة لكن AMI فشل: {report['ami_socket_check']['error']}"
    else:
        report["summary"] = f"🟢 الاتصال بـ Elastix/Asterisk سليم: CDR={report['mysql_pymysql_check']['records']} سجل"
    return report

@frappe.whitelist(allow_guest=False)
def test_cdr_db_connection() -> dict:
    rows, err = query_asterisk_cdr_with_error("SELECT COUNT(*) as cnt FROM cdr;")
    if rows:
        return {"success": True, "count": rows[0].get("cnt"), "message": f"✅ CDR connection OK. Records: {rows[0].get('cnt')}"}
    return {"success": False, "message": f"❌ CDR connection failed: {err}"}

def query_asterisk_cdr(sql: str) -> list[dict]:
    rows, _ = query_asterisk_cdr_with_error(sql)
    return rows

def query_asterisk_cdr_with_error(sql: str) -> tuple[list[dict], str | None]:
    host = _settings_host(); db = _db_name(); err_log = []
    # v23 proven fix: try PyMySQL with primary then fallback user, two attempts each, then CLI fallback.
    for u, p in _db_credentials():
        if not u: continue
        for attempt in range(1, 3):
            try:
                import pymysql
                conn = pymysql.connect(host=host, user=u, password=p, database=db, port=3306,
                                       connect_timeout=4, read_timeout=12, autocommit=True,
                                       cursorclass=pymysql.cursors.DictCursor)
                try:
                    with conn.cursor() as cur:
                        cur.execute(sql)
                        return list(cur.fetchall()), None
                finally:
                    try: conn.close()
                    except Exception: pass
            except Exception as e:
                err_log.append(f"[{u} try {attempt}: {e}]"); time.sleep(0.25 * attempt)
    try:
        u, p = _db_credentials()[0]
        r = subprocess.run(['mysql','-h',host,'-u',u,f'-p{p}',db,'--batch','--raw','-e',sql], capture_output=True, text=True, timeout=MYSQL_TIMEOUT)
        if r.returncode == 0:
            lines = r.stdout.strip().split('\n')
            if len(lines) >= 2:
                headers = lines[0].split('\t')
                return [dict(zip(headers, line.split('\t'))) for line in lines[1:]], None
            return [], None
        err_log.append(f"[mysql cli: {r.stderr.strip()}]")
    except Exception as e:
        err_log.append(f"[mysql cli exc: {e}]")
    return [], " | ".join(err_log)

def classify_call(call: dict) -> tuple[str, bool]:
    disp = (call.get('disposition') or '').upper(); duration = int(call.get('duration') or 0); billsec = int(call.get('billsec') or 0)
    if disp == 'ANSWERED' and billsec > 0: return 'answered', True
    if disp == 'BUSY': return 'busy', False
    if disp == 'FAILED': return 'failed', False
    if disp == 'NO ANSWER': return ('missed_by_agent' if duration >= MISSED_THRESHOLD_SEC else 'customer_hung_up'), False
    return 'unknown', False

def build_recording_url(recording_file: str) -> str:
    if not recording_file: return ''
    try:
        base = frappe.get_single("Call Center Settings").asterisk_recording_web_base or _conf("asterisk_recording_web_base", "http://10.11.1.253/monitor/")
    except Exception:
        base = _conf("asterisk_recording_web_base", "http://10.11.1.253/monitor/")
    return str(recording_file).replace("/var/spool/asterisk/monitor/", base)

def find_employee_at_time(extension: str, call_time):
    if not extension: return None
    try:
        call_time = get_datetime(call_time)
    except Exception:
        pass
    rows = frappe.db.sql("""
        SELECT s.employee FROM `tabExtension Session` s
        WHERE s.extension=%s AND s.started_at<=%s AND (s.released_at IS NULL OR s.released_at >= %s)
        ORDER BY s.started_at DESC LIMIT 1
    """, (extension, call_time, call_time), as_dict=True)
    return rows[0].employee if rows else None

@frappe.whitelist(allow_guest=False)
def stress_elastix_connections(attempts: int = 10) -> dict:
    """Run repeated CDR + AMI checks after install so connection issues are exposed loudly."""
    attempts = max(1, min(int(attempts or 10), 50))
    out = {"attempts": attempts, "cdr_ok": 0, "ami_ok": 0, "runs": [], "success": False}
    for i in range(1, attempts + 1):
        run = {"i": i, "cdr": False, "ami": False, "cdr_error": None, "ami_error": None, "cdr_count": 0, "orders": 0, "complaints": 0}
        try:
            rows, err = query_asterisk_cdr_with_error("SELECT COUNT(*) as cnt FROM cdr;")
            if rows:
                run["cdr"] = True; run["cdr_count"] = int(rows[0].get("cnt") or 0); out["cdr_ok"] += 1
            else:
                run["cdr_error"] = err
        except Exception as e:
            run["cdr_error"] = str(e)
        try:
            from restaurant_ops.api.queue_api import get_queue_status
            q = get_queue_status()
            if q.get("success"):
                run["ami"] = True; run["orders"] = q.get("orders", 0); run["complaints"] = q.get("complaints", 0); out["ami_ok"] += 1
            else:
                run["ami_error"] = q.get("error")
        except Exception as e:
            run["ami_error"] = str(e)
        out["runs"].append(run)
    out["success"] = (out["cdr_ok"] == attempts and out["ami_ok"] == attempts)
    out["summary"] = f"CDR OK {out['cdr_ok']}/{attempts} | AMI OK {out['ami_ok']}/{attempts}"
    return out
