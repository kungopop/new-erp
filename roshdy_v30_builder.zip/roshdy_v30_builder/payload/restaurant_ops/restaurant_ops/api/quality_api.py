import frappe
from restaurant_ops.api.common import has_any, QUALITY_ROLES, employee_name_for_user

@frappe.whitelist()
def get_quality_stats() -> dict:
    try:
        if not has_any(QUALITY_ROLES): return {}
        return {
            "total_complaints": frappe.db.count("Call Center Complaint") or 0,
            "resolved_complaints": frappe.db.count("Call Center Complaint", {"status": ["in", ["Closed", "Resolved"]]}) or 0,
            "open_complaints": frappe.db.count("Call Center Complaint", {"status": ["in", ["Draft", "Open", "Under Review"]]}) or 0,
            "urgent_complaints": frappe.db.count("Call Center Complaint", {"complaint_priority": ["in", ["High", "Urgent"]], "status": ["!=", "Resolved"]}) or 0,
            "employee_name": employee_name_for_user(),
        }
    except Exception as e:
        return {"error": str(e)}
