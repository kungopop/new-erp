import frappe
from frappe.utils import today, now_datetime
from restaurant_ops.api.common import has_any, employee_for_user, fail, ok

ADMIN_ROLES = {"Call Center Admin", "System Manager"}

@frappe.whitelist()
def get_active_items() -> list[dict]:
    try:
        if frappe.session.user == "Guest": return []
        return frappe.get_all("Sales Item", filters={"active": 1}, fields=["name", "item_name", "item_category"], order_by="item_name asc", limit_page_length=500)
    except Exception:
        return []

@frappe.whitelist()
def log_sale(item: str, quantity: int, customer_name: str = "", customer_phone: str = "", notes: str | None = None) -> dict:
    try:
        if frappe.session.user == "Guest": return fail("Please login first")
        emp = employee_for_user()
        if not emp: return fail("No Employee record")
        if not frappe.db.exists("Sales Item", item): return fail("Item not found")
        qty = int(quantity or 0)
        if qty < 1: return fail("Quantity must be >= 1")
        doc = frappe.get_doc({"doctype": "Sales Entry", "agent": emp, "sale_date": now_datetime(), "item": item, "quantity": qty,
                              "customer_name": (customer_name or "").strip(), "customer_phone": (customer_phone or "").strip(),
                              "notes": (notes or "").strip() or None}).insert(ignore_permissions=True)
        frappe.db.commit(); return ok(sale_id=doc.name, message="Sale logged successfully")
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def get_my_sales_today() -> list[dict]:
    try:
        if frappe.session.user == "Guest": return []
        emp = employee_for_user()
        if not emp: return []
        rows = frappe.db.sql("""
            SELECT s.name, s.sale_date, s.item, i.item_name, s.quantity, s.customer_name, s.customer_phone, s.creation
            FROM `tabSales Entry` s LEFT JOIN `tabSales Item` i ON s.item=i.name
            WHERE s.agent=%s AND DATE(s.sale_date)=%s ORDER BY s.creation DESC
        """, (emp, today()), as_dict=True)
        for r in rows:
            r.sale_date = str(r.sale_date) if r.sale_date else ""; r.creation = str(r.creation) if r.creation else ""
        return rows
    except Exception:
        return []

@frappe.whitelist()
def get_sales_report(date_from: str | None = None, date_to: str | None = None, agent: str | None = None, item: str | None = None) -> dict:
    try:
        if not has_any(ADMIN_ROLES): return {"sales": [], "per_agent": [], "per_item": [], "total_count": 0, "total_qty": 0}
        date_from = date_from or today(); date_to = date_to or today()
        cond = "DATE(s.sale_date) BETWEEN %s AND %s"; params = [date_from, date_to]
        if agent: cond += " AND s.agent=%s"; params.append(agent)
        if item: cond += " AND s.item=%s"; params.append(item)
        rows = frappe.db.sql(f"""
            SELECT s.name, s.sale_date, s.agent, e.employee_name, s.item, i.item_name, s.quantity, s.customer_name, s.customer_phone, s.creation
            FROM `tabSales Entry` s JOIN `tabEmployee` e ON s.agent=e.name LEFT JOIN `tabSales Item` i ON s.item=i.name
            WHERE {cond} ORDER BY s.creation DESC
        """, params, as_dict=True)
        per_agent, per_item = {}, {}
        for s in rows:
            per_agent.setdefault(s.employee_name, {"employee_name": s.employee_name, "sales_count": 0, "total_qty": 0})
            per_agent[s.employee_name]["sales_count"] += 1; per_agent[s.employee_name]["total_qty"] += int(s.quantity or 0)
            label = s.item_name or s.item
            per_item.setdefault(label, {"item": label, "sales_count": 0, "total_qty": 0})
            per_item[label]["sales_count"] += 1; per_item[label]["total_qty"] += int(s.quantity or 0)
            s.sale_date = str(s.sale_date) if s.sale_date else ""; s.creation = str(s.creation) if s.creation else ""
        return {"sales": rows, "per_agent": list(per_agent.values()), "per_item": list(per_item.values()), "total_count": len(rows), "total_qty": sum(int(s.quantity or 0) for s in rows)}
    except Exception as e:
        return {"sales": [], "per_agent": [], "per_item": [], "total_count": 0, "total_qty": 0, "error": str(e)}

@frappe.whitelist()
def add_item(item_name: str, item_category: str = "Food") -> dict:
    try:
        if not has_any(ADMIN_ROLES): return fail("Permission denied")
        item_name = (item_name or "").strip()
        if not item_name: return fail("Item name required")
        if frappe.db.exists("Sales Item", item_name): return fail("Item already exists")
        frappe.get_doc({"doctype": "Sales Item", "item_name": item_name, "item_category": item_category, "category": item_category, "active": 1, "is_active": 1}).insert(ignore_permissions=True)
        frappe.db.commit(); return ok(message=f"Item {item_name} added")
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def list_items_admin() -> list[dict]:
    try:
        if not has_any(ADMIN_ROLES): return []
        return frappe.get_all("Sales Item", fields=["name", "item_name", "item_category", "active"], order_by="item_name asc", limit_page_length=500)
    except Exception:
        return []

@frappe.whitelist()
def toggle_item(item_name: str, active: int) -> dict:
    try:
        if not has_any(ADMIN_ROLES): return fail("Permission denied")
        if not frappe.db.exists("Sales Item", item_name): return fail("Not found")
        frappe.db.set_value("Sales Item", item_name, {"active": int(active), "is_active": int(active)})
        frappe.db.commit(); return ok()
    except Exception as e:
        return fail(e)
