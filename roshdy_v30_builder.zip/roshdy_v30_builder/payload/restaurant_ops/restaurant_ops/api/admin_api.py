import frappe
from frappe.utils.password import update_password
from restaurant_ops.api.common import has_any, ADMIN_ROLES, employee_name_for_user, ok, fail

VALID_ROLES = ["Restaurant Agent", "Break Admin", "Call Center Admin", "Complaint_Quality_User", "Complaint_Finance_User"]

def _require_admin() -> bool:
    return has_any(ADMIN_ROLES)

@frappe.whitelist()
def get_admin_dashboard_stats() -> dict:
    try:
        if not _require_admin():
            return fail("Permission denied")
        today = frappe.utils.today()
        return {
            "active_breaks": frappe.db.count("Employee Break Log", {"status": "active"}) or 0,
            "open_complaints": frappe.db.count("Call Center Complaint", {"status": ["not in", ["Closed", "Resolved"]]}) or 0,
            "today_complaints": frappe.db.count("Call Center Complaint", {"resolved_at": [">=", f"{today} 00:00:00"]}) or 0,
            "today_calls": frappe.db.count("Call Record", {"call_datetime": [">=", f"{today} 00:00:00"]}) or 0,
            "employee_name": employee_name_for_user(),
        }
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def create_agent(email: str, full_name: str, password: str, role: str = "Restaurant Agent") -> dict:
    return create_user(email=email, full_name=full_name, password=password, role=role)

@frappe.whitelist()
def create_user(email: str, full_name: str, password: str, role: str = "Restaurant Agent", old_system_id: str = "") -> dict:
    try:
        if not _require_admin(): return fail("Permission denied")
        email = (email or "").strip().lower()
        full_name = (full_name or "").strip()
        if not email or "@" not in email: return fail("Invalid email")
        if not full_name: return fail("Full name required")
        if frappe.db.exists("User", email): return fail("User already exists")
        if len(password or "") < 6: return fail("Password must be at least 6 chars")
        if role not in VALID_ROLES: return fail(f"Invalid role: {role}")
        first, _, last = full_name.partition(" ")
        user = frappe.get_doc({"doctype": "User", "email": email, "first_name": first, "last_name": last or first,
                               "enabled": 1, "user_type": "System User", "send_welcome_email": 0,
                               "language": "en", "time_zone": "Africa/Cairo"}).insert(ignore_permissions=True)
        update_password(user.name, password)
        if frappe.db.exists("Role", role):
            user.append("roles", {"role": role})
            user.save(ignore_permissions=True)
        company = frappe.db.get_value("Company", {}, "name") or "roshdy"
        emp = frappe.get_doc({"doctype": "Employee", "employee_name": full_name, "first_name": first, "last_name": last or first,
                              "gender": "Male", "date_of_birth": "1995-01-01", "date_of_joining": frappe.utils.today(),
                              "status": "Active", "company": company, "user_id": email, "personal_email": email,
                              "old_system_id": old_system_id or ""}).insert(ignore_permissions=True)
        frappe.db.commit()
        return ok(user=user.name, employee=emp.name)
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def toggle_user(user_id: str, enabled: int) -> dict:
    try:
        if not _require_admin(): return fail("Permission denied")
        if user_id == "Administrator": return fail("Cannot disable Administrator")
        frappe.db.set_value("User", user_id, "enabled", int(enabled))
        emp = frappe.db.get_value("Employee", {"user_id": user_id}, "name")
        if emp:
            frappe.db.set_value("Employee", emp, "status", "Active" if int(enabled) else "Left")
        frappe.db.commit()
        return ok(user=user_id, enabled=int(enabled))
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def reset_user_password(user_id: str, new_password: str) -> dict:
    return reset_password(user_id, new_password)

@frappe.whitelist()
def reset_password(user_id: str, new_password: str) -> dict:
    try:
        if not _require_admin(): return fail("Permission denied")
        if len(new_password or "") < 6: return fail("Password must be at least 6 chars")
        update_password(user_id, new_password)
        frappe.db.commit()
        return ok(user=user_id)
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def update_user_roles(user_id: str, roles: str) -> dict:
    try:
        if not _require_admin(): return fail("Permission denied")
        if user_id == "Administrator": return fail("Cannot modify Administrator roles")
        user = frappe.get_doc("User", user_id)
        keep = [r for r in user.roles if r.role in ("All", "Guest", "Desk User")]
        user.roles = keep
        for r in (roles or "").split(","):
            r = r.strip()
            if r and frappe.db.exists("Role", r): user.append("roles", {"role": r})
        user.save(ignore_permissions=True)
        frappe.db.commit()
        return ok(user=user_id, roles=[r.role for r in user.roles])
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def list_all_users() -> list[dict]:
    return get_all_users()

@frappe.whitelist()
def get_all_users() -> list[dict]:
    try:
        if not _require_admin(): return []
        users = frappe.get_all("User", filters={"user_type": "System User", "name": ["!=", "Guest"]},
                               fields=["name", "email", "first_name", "last_name", "enabled", "last_login"],
                               order_by="first_name asc", limit_page_length=500)
        for u in users:
            u.roles = [r.role for r in frappe.get_all("Has Role", filters={"parent": u.name}, fields=["role"])]
            emp = frappe.db.get_value("Employee", {"user_id": u.name}, ["name", "employee_name", "old_system_id"], as_dict=True)
            u.employee_id = emp.name if emp else ""
            u.employee_name = emp.employee_name if emp else ((u.first_name or "") + " " + (u.last_name or "")).strip()
            u.old_system_id = emp.old_system_id if emp else ""
        return users
    except Exception:
        return []

@frappe.whitelist()
def get_settings() -> dict:
    try:
        if not _require_admin(): return {}
        d = frappe.get_single("Call Center Settings").as_dict()
        d["employee_name"] = employee_name_for_user()
        return d
    except Exception:
        return {}

@frappe.whitelist()
def save_settings(daily_report_enabled: int = 1, daily_report_recipients: str = "",
                  center_manager_recipients: str = "", upper_management_recipients: str = "",
                  shift_start_hour: int = 10, shift_end_hour: int = 5,
                  asterisk_host: str = "10.11.1.253", asterisk_ami_port: int = 5038,
                  asterisk_recording_web_base: str = "") -> dict:
    return update_settings(daily_report_enabled, daily_report_recipients, center_manager_recipients,
                           upper_management_recipients, shift_start_hour, shift_end_hour,
                           asterisk_host, asterisk_ami_port, asterisk_recording_web_base)

@frappe.whitelist()
def update_settings(daily_report_enabled: int = 1, daily_report_recipients: str = "",
                    center_manager_recipients: str = "", upper_management_recipients: str = "",
                    shift_start_hour: int = 10, shift_end_hour: int = 5,
                    asterisk_host: str = "10.11.1.253", asterisk_ami_port: int = 5038,
                    asterisk_recording_web_base: str = "") -> dict:
    try:
        if not _require_admin(): return fail("Permission denied")
        doc = frappe.get_single("Call Center Settings")
        doc.daily_report_enabled = int(daily_report_enabled)
        doc.daily_report_recipients = daily_report_recipients or doc.daily_report_recipients
        doc.center_manager_recipients = center_manager_recipients or doc.center_manager_recipients
        doc.upper_management_recipients = upper_management_recipients or doc.upper_management_recipients
        doc.shift_start_hour = int(shift_start_hour)
        doc.shift_end_hour = int(shift_end_hour)
        doc.asterisk_host = asterisk_host
        doc.asterisk_ami_port = int(asterisk_ami_port)
        if asterisk_recording_web_base: doc.asterisk_recording_web_base = asterisk_recording_web_base
        doc.save(ignore_permissions=True)
        frappe.db.commit()
        return ok()
    except Exception as e:
        return fail(e)
