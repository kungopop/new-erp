import frappe
from frappe.utils import now_datetime
from restaurant_ops.api.common import has_any, employee_for_user, employee_name_for_user, fail, ok

ADMIN_ROLES = {"Call Center Admin", "System Manager", "Break Admin", "Complaint_Finance_User", "Complaint_Quality_User"}

def is_admin(user=None) -> bool:
    return has_any(ADMIN_ROLES, user)

@frappe.whitelist()
def user_needs_extension() -> dict:
    user = frappe.session.user
    if not user or user == "Guest": return {"needs_extension": False, "reason": "guest"}
    if is_admin(user): return {"needs_extension": False, "reason": "admin"}
    return {"needs_extension": True, "reason": "agent"}

@frappe.whitelist()
def get_available_extensions() -> list[dict]:
    try:
        user = frappe.session.user
        if user == "Guest": return []
        all_ext = frappe.get_all("SIP Extension", filters={"active": 1}, fields=["name", "extension_number", "description"], order_by="extension_number asc", limit_page_length=100)
        sessions = frappe.db.sql("""
            SELECT s.extension, s.user, e.employee_name FROM `tabExtension Session` s
            LEFT JOIN `tabEmployee` e ON s.employee=e.name WHERE s.session_status='active'
        """, as_dict=True)
        taken = {s.extension: (s.user, s.employee_name) for s in sessions}
        out = []
        for ext in all_ext:
            t = taken.get(ext.name)
            out.append({"extension_number": ext.extension_number, "description": ext.description or "", "taken": bool(t),
                        "taken_by_user": t[0] if t else None, "taken_by_name": (t[1] or t[0].split('@')[0]) if t else None,
                        "is_mine": (t[0] == user) if t else False})
        return out
    except Exception:
        return []

@frappe.whitelist()
def select_extension(extension_number: str) -> dict:
    try:
        user = frappe.session.user
        if user == "Guest": return fail("Please login first")
        if is_admin(user): return fail("Admins don't use SIP extensions")
        if not frappe.db.exists("SIP Extension", extension_number): return fail("Extension not found")
        existing = frappe.db.get_value("Extension Session", {"user": user, "session_status": "active"}, ["name", "extension"], as_dict=True)
        if existing:
            if existing.extension == extension_number: return ok(extension=extension_number, message="Already using this extension")
            prev = frappe.get_doc("Extension Session", existing.name); prev.session_status = "released"; prev.active = 0; prev.released_at = now_datetime(); prev.save(ignore_permissions=True)
            frappe.db.set_value("SIP Extension", existing.extension, {"status": "Free", "current_user": None})
        other = frappe.db.get_value("Extension Session", {"extension": extension_number, "session_status": "active", "user": ["!=", user]}, ["user"], as_dict=True)
        if other: return fail(f"Extension {extension_number} is used by {other.user}")
        emp = employee_for_user(user)
        session = frappe.get_doc({"doctype": "Extension Session", "user": user, "employee": emp, "extension": extension_number,
                                  "session_status": "active", "active": 1, "started_at": now_datetime(),
                                  "ip_address": getattr(frappe.local, 'request_ip', '') or ''}).insert(ignore_permissions=True)
        frappe.db.set_value("SIP Extension", extension_number, {"status": "Busy", "current_user": user})
        frappe.db.commit()
        return ok(extension=extension_number, session_id=session.name, message=f"Extension {extension_number} is now yours")
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def release_my_extension() -> dict:
    try:
        user = frappe.session.user
        if user == "Guest": return fail("Not logged in")
        session_name = frappe.db.get_value("Extension Session", {"user": user, "session_status": "active"}, "name")
        if not session_name: return fail("No active extension")
        session = frappe.get_doc("Extension Session", session_name)
        session.session_status = "released"; session.active = 0; session.released_at = now_datetime(); session.save(ignore_permissions=True)
        frappe.db.set_value("SIP Extension", session.extension, {"status": "Free", "current_user": None})
        frappe.db.commit(); return ok(message="Extension released")
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def get_my_extension() -> dict | None:
    try:
        user = frappe.session.user
        if user == "Guest": return None
        s = frappe.db.get_value("Extension Session", {"user": user, "session_status": "active"}, ["name", "extension", "started_at"], as_dict=True)
        if s:
            s["started_at"] = str(s["started_at"]); s["employee_name"] = employee_name_for_user(user)
        return s
    except Exception:
        return None

@frappe.whitelist()
def admin_release_extension(extension_number: str) -> dict:
    try:
        if not has_any({"Break Admin", "Call Center Admin", "System Manager"}): return fail("Permission denied")
        session_name = frappe.db.get_value("Extension Session", {"extension": extension_number, "session_status": "active"}, "name")
        if not session_name: return fail("No active session")
        s = frappe.get_doc("Extension Session", session_name); s.session_status = "forced_release"; s.active = 0; s.released_at = now_datetime(); s.save(ignore_permissions=True)
        frappe.db.set_value("SIP Extension", extension_number, {"status": "Free", "current_user": None})
        frappe.db.commit(); return ok(message=f"Extension {extension_number} released")
    except Exception as e:
        return fail(e)
