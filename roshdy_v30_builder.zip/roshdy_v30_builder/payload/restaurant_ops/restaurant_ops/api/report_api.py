import frappe
from frappe.utils import today
from restaurant_ops.api.common import has_any, REPORT_ROLES
import re, math

DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

def _safe_date(v, default):
    v = (v or default or today()).strip()
    return v if DATE_RE.match(v) else default

def _safe_search(v):
    return re.sub(r"[^0-9A-Za-z+_.@-]", "", (v or "").strip())[:40]

@frappe.whitelist()
def get_calls_report(date_from: str | None = None, date_to: str | None = None, smart_category: str | None = None,
                     search: str | None = None, page: int = 1, page_size: int = 100) -> dict:
    try:
        if not has_any(REPORT_ROLES):
            return {"summary": {}, "calls": [], "error": "Permission denied", "pagination": {"total_records": 0, "total_pages": 1, "current_page": 1, "page_size": 100}}
        date_from = _safe_date(date_from, today()); date_to = _safe_date(date_to, today())
        page = max(1, int(page or 1)); page_size = min(500, max(20, int(page_size or 100)))
        from restaurant_ops.api.asterisk_bridge import query_asterisk_cdr_with_error, build_recording_url
        where = [f"calldate BETWEEN '{date_from} 00:00:00' AND '{date_to} 23:59:59'"]
        s = _safe_search(search)
        if s:
            where.append(f"(src LIKE '%{s}%' OR dst LIKE '%{s}%' OR userfield LIKE '%{s}%' OR dstchannel LIKE '%{s}%')")
        if smart_category == "answered": where.append("disposition = 'ANSWERED'")
        elif smart_category == "staff_missed": where.append("(disposition = 'NO ANSWER' OR disposition = 'FAILED') AND duration >= 15")
        elif smart_category == "abandoned": where.append("(disposition = 'NO ANSWER' OR disposition = 'FAILED') AND duration < 15")
        elif smart_category == "busy": where.append("disposition = 'BUSY'")
        where_sql = "WHERE " + " AND ".join(where)
        summary_sql = f"""
            SELECT COUNT(*) as total,
                   SUM(CASE WHEN disposition = 'ANSWERED' THEN 1 ELSE 0 END) as answered,
                   SUM(CASE WHEN disposition = 'BUSY' THEN 1 ELSE 0 END) as declined,
                   SUM(CASE WHEN (disposition = 'NO ANSWER' OR disposition = 'FAILED') AND duration < 15 THEN 1 ELSE 0 END) as abandoned,
                   SUM(CASE WHEN (disposition = 'NO ANSWER' OR disposition = 'FAILED') AND duration >= 15 THEN 1 ELSE 0 END) as staff_missed
            FROM cdr {where_sql};
        """
        summary_rows, summary_err = query_asterisk_cdr_with_error(summary_sql)
        summary = summary_rows[0] if summary_rows else {"total": 0, "answered": 0, "declined": 0, "abandoned": 0, "staff_missed": 0}
        for k in ["total", "answered", "declined", "abandoned", "staff_missed"]: summary[k] = int(summary.get(k) or 0)
        total_records = summary["total"]; total_pages = max(1, math.ceil(total_records / page_size)); offset = (page - 1) * page_size
        records_sql = f"SELECT * FROM cdr {where_sql} ORDER BY calldate DESC LIMIT {page_size} OFFSET {offset};"
        records, records_err = query_asterisk_cdr_with_error(records_sql)
        if not records and (records_err or summary_err):
            return {"summary": summary, "calls": [], "error": records_err or summary_err, "pagination": {"total_records": 0, "total_pages": 1, "current_page": 1, "page_size": page_size}}
        sessions = frappe.db.sql("""
            SELECT s.extension, s.started_at, s.released_at, e.employee_name, s.user
            FROM `tabExtension Session` s LEFT JOIN `tabEmployee` e ON s.employee=e.name OR s.user=e.user_id
        """, as_dict=True)
        for r in records:
            calldate_str = str(r.get("calldate") or "")
            disp = (r.get("disposition") or "").upper(); duration = int(r.get("duration") or 0)
            dst = str(r.get("dst") or ""); dstchannel = str(r.get("dstchannel") or r.get("channel") or "")
            actual_ext = ""
            m = re.search(r'SIP/(\d{4})', dstchannel, re.I)
            if m: actual_ext = m.group(1)
            elif re.match(r'^\d{4}$', dst): actual_ext = dst
            r["actual_ext"] = actual_ext or dst
            if disp == 'ANSWERED': r["smart_category"] = "answered"; r["category_label"] = "🟢 تم الرد"
            elif disp == 'BUSY': r["smart_category"] = "busy"; r["category_label"] = "🟡 مشغول / رُفض"
            elif disp in ('NO ANSWER', 'FAILED') and duration >= 15: r["smart_category"] = "staff_missed"; r["category_label"] = "🔴 فائتة من الموظف (>= 15ث)"
            else: r["smart_category"] = "abandoned"; r["category_label"] = "⚪ انقطع في البدالة (< 15ث)"
            resolved = ""
            if actual_ext and re.match(r'^\d{4}$', actual_ext):
                for ss in sessions:
                    if str(ss.extension) == str(actual_ext):
                        start = str(ss.started_at or ""); rel = str(ss.released_at or "2099-12-31")
                        if start <= calldate_str <= rel:
                            resolved = ss.employee_name or ss.user; break
                r["agent_name"] = f"{resolved} ({actual_ext})" if resolved else (f"⚠️ عمل بدون اختيار SIP على {actual_ext}" if disp == 'ANSWERED' else f"تحويلة {actual_ext} غير مربوطة")
            else:
                r["agent_name"] = "طابور انتظار / IVR" if dst in ("1234", "123") else f"بدالة / IVR ({dst})"
            r["recording_url"] = build_recording_url(r.get("recordingfile") or "")
        return {"summary": summary, "calls": records, "pagination": {"total_records": total_records, "total_pages": total_pages, "current_page": page, "page_size": page_size}}
    except Exception as e:
        return {"summary": {}, "calls": [], "error": str(e), "pagination": {"total_records": 0, "total_pages": 1, "current_page": 1, "page_size": 100}}
