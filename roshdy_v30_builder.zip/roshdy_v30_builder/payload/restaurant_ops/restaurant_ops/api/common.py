import frappe

ADMIN_ROLES = {"Call Center Admin", "System Manager", "Break Admin", "Complaint_Finance_User"}
QUALITY_ROLES = {"Complaint_Quality_User", "Call Center Admin", "System Manager"}
REPORT_ROLES = {"Call Center Admin", "System Manager", "Break Admin", "Complaint_Quality_User", "Complaint_Finance_User"}
AGENT_ROLE = "Restaurant Agent"

def roles(user=None):
    user = user or frappe.session.user
    if not user or user == "Guest":
        return []
    try:
        return frappe.get_roles(user)
    except Exception:
        return []

def has_any(allowed, user=None):
    user = user or frappe.session.user
    return user == "Administrator" or bool(set(roles(user)) & set(allowed))

def employee_for_user(user=None):
    user = user or frappe.session.user
    if not user or user == "Guest":
        return None
    return frappe.db.get_value("Employee", {"user_id": user}, "name")

def employee_name_for_user(user=None):
    user = user or frappe.session.user
    if not user or user == "Guest":
        return "Guest"
    return frappe.db.get_value("Employee", {"user_id": user}, "employee_name") or (user.split("@")[0] if "@" in user else user)

def ok(**kwargs):
    data = {"success": True}
    data.update(kwargs)
    return data

def fail(message="Error", **kwargs):
    data = {"success": False, "message": str(message)}
    data.update(kwargs)
    return data
