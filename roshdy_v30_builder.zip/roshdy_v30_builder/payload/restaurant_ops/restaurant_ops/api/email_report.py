import frappe
from frappe.utils import today, now_datetime


def _fmt(sec):
    sec = int(sec or 0); return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}"

def _recipients(raw):
    return [x.strip() for x in (raw or "").split(",") if x.strip()]

def send_daily_shift_report() -> dict:
    try:
        settings = frappe.get_single("Call Center Settings")
        if not settings.daily_report_enabled:
            return {"success": False, "message": "Daily report disabled"}
        r1 = send_center_manager_report(settings)
        r2 = send_upper_management_report(settings)
        return {"success": True, "message": f"Center: {r1.get('message')} | Upper: {r2.get('message')}"}
    except Exception as e:
        return {"success": False, "message": str(e)}

def send_center_manager_report(settings) -> dict:
    try:
        recipients = _recipients(getattr(settings, "center_manager_recipients", "") or getattr(settings, "daily_report_recipients", "") or "el.alfy@roshdy.com")
        if not recipients: return {"success": False, "message": "No center manager recipients"}
        dt = today()
        calls_total = frappe.db.count("Call Record", {"call_datetime": [">=", f"{dt} 00:00:00"]})
        calls_answered = frappe.db.count("Call Record", {"call_datetime": [">=", f"{dt} 00:00:00"], "smart_category": "answered"})
        comp_total = frappe.db.count("Call Center Complaint", {"complaint_datetime": [">=", f"{dt} 00:00:00"]})
        comp_resolved = frappe.db.count("Call Center Complaint", {"complaint_datetime": [">=", f"{dt} 00:00:00"], "status": ["in", ["Closed", "Resolved"]]})
        emp_breaks = frappe.db.sql("""
            SELECT e.employee_name, COUNT(b.name) brk_cnt, COALESCE(SUM(b.duration_seconds), 0) total_sec
            FROM `tabEmployee` e JOIN `tabEmployee Break Log` b ON e.name=b.employee
            WHERE b.break_date=%s AND b.status='finished' GROUP BY e.employee_name ORDER BY total_sec DESC
        """, (dt,), as_dict=True)
        total_cnt = 0; total_sec = 0; lines = ""
        for eb in emp_breaks:
            total_cnt += int(eb.brk_cnt or 0); total_sec += int(eb.total_sec or 0)
            lines += f"   • {eb.employee_name}: {eb.brk_cnt} بريك | إجمالي الوقت: {_fmt(eb.total_sec)}\n"
        if not lines: lines = "   • لا توجد بريكات مكتملة اليوم\n"
        subject = f"📋 تقرير مدير السنتر وبريكات الموظفين — {dt}"
        body = f"""تقرير مدير الكول سنتر — مطعم رشدي
التاريخ: {dt} | وقت التقرير: {now_datetime()}
============================================================
📞 المكالمات والشكاوى:
   • إجمالي المكالمات: {calls_total}
   • تم الرد: {calls_answered}
   • إجمالي الشكاوى: {comp_total} (مغلق/محلول: {comp_resolved})

⏱️ بريكات الموظفين:
   • إجمالي عدد البريكات: {total_cnt}
   • إجمالي وقت البريكات: {_fmt(total_sec)}
------------------------------------------------------------
{lines}
============================================================
"""
        frappe.sendmail(recipients=recipients, subject=subject, message=body, now=True)
        return {"success": True, "message": f"sent to {len(recipients)}"}
    except Exception as e:
        return {"success": False, "message": str(e)}

def send_upper_management_report(settings) -> dict:
    try:
        recipients = _recipients(getattr(settings, "upper_management_recipients", "") or "admin@roshdy.com")
        if not recipients: return {"success": False, "message": "No upper management recipients"}
        dt = today()
        calls_total = frappe.db.count("Call Record", {"call_datetime": [">=", f"{dt} 00:00:00"]})
        calls_answered = frappe.db.count("Call Record", {"call_datetime": [">=", f"{dt} 00:00:00"], "smart_category": "answered"})
        calls_missed_staff = frappe.db.count("Call Record", {"call_datetime": [">=", f"{dt} 00:00:00"], "smart_category": "missed_by_agent"})
        calls_abandoned = frappe.db.count("Call Record", {"call_datetime": [">=", f"{dt} 00:00:00"], "smart_category": "customer_hung_up"})
        calls_busy = frappe.db.count("Call Record", {"call_datetime": [">=", f"{dt} 00:00:00"], "smart_category": "busy"})
        comp_total = frappe.db.count("Call Center Complaint", {"complaint_datetime": [">=", f"{dt} 00:00:00"]})
        comp_resolved = frappe.db.count("Call Center Complaint", {"complaint_datetime": [">=", f"{dt} 00:00:00"], "status": ["in", ["Closed", "Resolved"]]})
        comp_open = frappe.db.count("Call Center Complaint", {"complaint_datetime": [">=", f"{dt} 00:00:00"], "status": ["not in", ["Closed", "Resolved"]]})
        cats = frappe.db.sql("SELECT complaint_category, COUNT(*) cnt FROM `tabCall Center Complaint` WHERE complaint_datetime >= %s GROUP BY complaint_category", (f"{dt} 00:00:00",), as_dict=True)
        cats_text = "".join([f"   • {c.complaint_category or 'أخرى'}: {c.cnt}\n" for c in cats]) or "   • لا توجد شكاوى اليوم\n"
        sold = frappe.db.sql("""
            SELECT i.item_name, COALESCE(SUM(s.quantity),0) total_qty
            FROM `tabSales Entry` s JOIN `tabSales Item` i ON s.item=i.name
            WHERE DATE(s.sale_date)=%s GROUP BY i.item_name ORDER BY total_qty DESC
        """, (dt,), as_dict=True)
        total_qty = sum(int(x.total_qty or 0) for x in sold)
        items_text = "".join([f"   • {x.item_name}: {x.total_qty} قطعة\n" for x in sold]) or "   • لا توجد مبيعات مسجلة اليوم\n"
        subject = f"📊 تقرير الإدارة العليا اليومي — {dt}"
        body = f"""تقرير الإدارة العليا — الكول سنتر والمبيعات
التاريخ: {dt} | وقت التقرير: {now_datetime()}
============================================================
📞 إحصائيات المكالمات:
   • إجمالي الوارد: {calls_total}
   • تم الرد: {calls_answered}
   • فائتة بسبب تأخر الموظف (>=15ث): {calls_missed_staff}
   • العميل أغلق الخط (<15ث): {calls_abandoned}
   • مشغول/مرفوض: {calls_busy}

📋 الشكاوى:
   • إجمالي: {comp_total} | محلول: {comp_resolved} | مفتوح: {comp_open}
{cats_text}
💰 المبيعات:
   • إجمالي القطع: {total_qty}
{items_text}
============================================================
"""
        frappe.sendmail(recipients=recipients, subject=subject, message=body, now=True)
        return {"success": True, "message": f"sent to {len(recipients)}"}
    except Exception as e:
        return {"success": False, "message": str(e)}

@frappe.whitelist()
def send_report_now() -> dict:
    return send_daily_shift_report()
