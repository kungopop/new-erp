import frappe
from frappe.utils import now_datetime, add_to_date, get_datetime
from restaurant_ops.api.asterisk_bridge import query_asterisk_cdr, classify_call, build_recording_url, find_employee_at_time
from restaurant_ops.api.common import has_any

def sync_recent_calls():
    try:
        since = add_to_date(now_datetime(), minutes=-10).strftime('%Y-%m-%d %H:%M:%S')
        rows = query_asterisk_cdr(f"SELECT uniqueid, calldate, src, dst, duration, billsec, disposition, recordingfile FROM cdr WHERE calldate >= '{since}' ORDER BY calldate ASC")
        if not rows:
            _update_status(0); return {"synced": 0, "message": "No rows or CDR connection failed"}
        synced = skipped = 0
        for row in rows:
            uniqueid = str(row.get('uniqueid') or '').strip()
            if not uniqueid: continue
            if frappe.db.exists("Call Record", uniqueid): skipped += 1; continue
            try: call_dt = get_datetime(row.get('calldate'))
            except Exception: call_dt = now_datetime()
            smart, answered = classify_call(row)
            doc = frappe.get_doc({"doctype": "Call Record", "uniqueid": uniqueid, "call_datetime": call_dt,
                                  "customer_number": row.get('src') or '', "extension": row.get('dst') or '',
                                  "employee_at_time": find_employee_at_time(row.get('dst') or '', call_dt),
                                  "duration_seconds": int(row.get('duration') or 0), "billsec": int(row.get('billsec') or 0),
                                  "disposition": row.get('disposition') or '', "smart_category": smart, "was_answered": 1 if answered else 0,
                                  "recording_file": row.get('recordingfile') or '', "recording_url": build_recording_url(row.get('recordingfile') or '')})
            try: doc.insert(ignore_permissions=True); synced += 1
            except Exception as e: frappe.log_error(title=f"Call Record insert failed {uniqueid}", message=str(e))
        frappe.db.commit(); _update_status(synced)
        return {"synced": synced, "skipped": skipped, "checked": len(rows)}
    except Exception as e:
        frappe.log_error(title="sync_recent_calls failed", message=str(e)); return {"synced": 0, "error": str(e)}

def _update_status(count: int):
    try:
        s = frappe.get_single("Call Center Settings"); s.last_call_sync = now_datetime(); s.last_call_sync_count = count; s.save(ignore_permissions=True); frappe.db.commit()
    except Exception: pass

@frappe.whitelist()
def manual_sync() -> dict:
    if not has_any({"Call Center Admin", "System Manager"}): return {"success": False, "message": "Permission denied"}
    res = sync_recent_calls(); res["success"] = True; return res

@frappe.whitelist()
def get_sync_status() -> dict:
    try:
        s = frappe.get_single("Call Center Settings")
        return {"last_sync": str(s.last_call_sync) if s.last_call_sync else None, "last_count": s.last_call_sync_count or 0}
    except Exception:
        return {"last_sync": None, "last_count": 0}
