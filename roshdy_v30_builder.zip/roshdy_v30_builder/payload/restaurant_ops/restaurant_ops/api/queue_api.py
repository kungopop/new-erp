import frappe
import socket
import re
import time


def _conf(key: str, default=None):
    return frappe.conf.get(key) or default

def _host_port():
    try:
        s = frappe.get_single("Call Center Settings")
        host = s.asterisk_host or _conf("asterisk_host", "10.11.1.253")
        port = int(s.asterisk_ami_port or _conf("asterisk_ami_port", 5038))
        return host, port
    except Exception:
        return _conf("asterisk_host", "10.11.1.253"), int(_conf("asterisk_ami_port", 5038))

def _ami_user_secret():
    return _conf("asterisk_ami_user", "phpadmin"), _conf("asterisk_ami_secret", "")

@frappe.whitelist(allow_guest=False)
def get_queue_status() -> dict:
    result = {"success": False, "orders": 0, "complaints": 0, "total": 0, "error": None, "raw": ""}
    host, port = _host_port(); user, secret = _ami_user_secret(); sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(5)
        sock.connect((host, port))
        # v23 stable AMI pattern: Login + QueueStatus + Command queue show + Logoff in one socket, then shutdown.
        cmd = (f"Action: Login\r\nUsername: {user}\r\nSecret: {secret}\r\n\r\n"
               f"Action: QueueStatus\r\n\r\n"
               f"Action: Command\r\nCommand: queue show\r\n\r\n"
               f"Action: Logoff\r\n\r\n")
        sock.sendall(cmd.encode())
        response = ""; start = time.time()
        while time.time() - start < 4.0:
            try:
                chunk = sock.recv(4096)
                if not chunk: break
                response += chunk.decode(errors="ignore")
                if "QueueStatusComplete" in response and ("Goodbye" in response or "queue show" in response): break
            except socket.timeout:
                break
            except Exception:
                break
        result["raw"] = response[:800]
        orders = complaints = 0
        for m in re.finditer(r'Queue:\s*(1234|123\b).*?(?:Calls|Callers):\s*(\d+)', response, re.DOTALL | re.I):
            q, cnt = m.group(1), int(m.group(2))
            if q == "1234": orders = max(orders, cnt)
            elif q == "123": complaints = max(complaints, cnt)
        for m in re.finditer(r'\b(1234|123\b)\s+has\s+(\d+)\s+call', response, re.I):
            q, cnt = m.group(1), int(m.group(2))
            if q == "1234": orders = max(orders, cnt)
            elif q == "123": complaints = max(complaints, cnt)
        result.update({"success": True, "orders": orders, "complaints": complaints, "total": orders + complaints})
    except Exception as e:
        result["error"] = str(e)
    finally:
        if sock:
            try: sock.shutdown(socket.SHUT_RDWR)
            except Exception: pass
            try: sock.close()
            except Exception: pass
    return result

@frappe.whitelist(allow_guest=False)
def test_ami_connection() -> dict:
    res = get_queue_status()
    host, port = _host_port()
    res["message"] = f"AMI {host}:{port} => success={res.get('success')} orders={res.get('orders')} complaints={res.get('complaints')} error={res.get('error')}"
    return res

@frappe.whitelist()
def check_extension_online(extension_number: str) -> dict:
    return {"extension": extension_number, "online": _check_extension_online(extension_number)}

def _check_extension_online(extension_number: str) -> bool:
    host, port = _host_port(); user, secret = _ami_user_secret(); sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(3.0); sock.connect((host, port))
        cmd = f"Action: Login\r\nUsername: {user}\r\nSecret: {secret}\r\n\r\nAction: SIPshowpeer\r\nPeer: {extension_number}\r\n\r\nAction: Logoff\r\n\r\n"
        sock.sendall(cmd.encode())
        resp = ""; start = time.time()
        while time.time() - start < 2.0:
            try:
                c = sock.recv(2048)
                if not c: break
                resp += c.decode(errors="ignore")
                if "Status:" in resp or "Reachable" in resp: break
            except Exception: break
        return bool(resp and ("Status: OK" in resp or "Reachable" in resp))
    except Exception:
        return False
    finally:
        if sock:
            try: sock.shutdown(socket.SHUT_RDWR)
            except Exception: pass
            try: sock.close()
            except Exception: pass
