import frappe
from frappe.utils import now_datetime, time_diff_in_seconds, today
from restaurant_ops.api.common import has_any, employee_for_user, fail, ok

BREAK_ADMIN_ROLES = {"Break Admin", "Call Center Admin", "System Manager"}

def _fmt(seconds) -> str:
    seconds = int(seconds or 0); return f"{seconds//3600:02d}:{(seconds%3600)//60:02d}:{seconds%60:02d}"

@frappe.whitelist()
def start_break(break_type: str | None = None, notes: str | None = None) -> dict:
    try:
        if frappe.session.user == "Guest": return fail("Please login first")
        employee = employee_for_user()
        if not employee: return fail("No Employee record linked")
        existing = frappe.db.get_value("Employee Break Log", {"employee": employee, "status": "active"}, "name")
        if existing: return fail("You already have an active break", break_id=existing)
        ext_session = frappe.db.get_value("Extension Session", {"user": frappe.session.user, "session_status": "active"}, ["extension"], as_dict=True)
        ext_name = ext_session.extension if ext_session else None
        ext_online = True; warning_note = notes or ""
        if ext_name:
            try:
                from restaurant_ops.api.queue_api import _check_extension_online
                ext_online = _check_extension_online(ext_name)
                if not ext_online: warning_note = f"⚠️ Extension {ext_name} was OFFLINE at break start. " + warning_note
            except Exception: pass
        now = now_datetime()
        doc = frappe.get_doc({"doctype": "Employee Break Log", "employee": employee, "break_date": now.date(), "start_time": now,
                              "status": "active", "break_type": break_type or None, "notes": warning_note or None,
                              "extension_at_start": ext_name, "extension_was_online": 1 if ext_online else 0})
        doc.insert(ignore_permissions=True); frappe.db.commit()
        return ok(break_id=doc.name, start_time=str(doc.start_time), extension_online=ext_online, extension=ext_name, message="Break started successfully")
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def end_break(break_id: str | None = None) -> dict:
    try:
        if frappe.session.user == "Guest": return fail("Please login first")
        employee = employee_for_user()
        if not employee: return fail("No Employee record linked")
        if break_id:
            doc = frappe.get_doc("Employee Break Log", break_id)
            if doc.employee != employee: return fail("This break doesn't belong to you")
        else:
            active = frappe.db.get_value("Employee Break Log", {"employee": employee, "status": "active"}, "name")
            if not active: return fail("No active break found")
            doc = frappe.get_doc("Employee Break Log", active)
        now = now_datetime(); duration = int(time_diff_in_seconds(now, doc.start_time))
        doc.end_time = now; doc.duration_seconds = duration; doc.duration_minutes = round(duration/60, 2)
        doc.status = "finished"; doc.closed_by = frappe.session.user; doc.closure_type = "employee"
        doc.save(ignore_permissions=True); frappe.db.commit()
        return ok(break_id=doc.name, duration_seconds=duration, duration_formatted=_fmt(duration), message="Break ended")
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def admin_end_break(break_id: str) -> dict:
    try:
        if not has_any(BREAK_ADMIN_ROLES): return fail("Permission denied")
        doc = frappe.get_doc("Employee Break Log", break_id)
        if doc.status != "active": return fail("Break is not active")
        now = now_datetime(); duration = int(time_diff_in_seconds(now, doc.start_time))
        doc.end_time = now; doc.duration_seconds = duration; doc.duration_minutes = round(duration/60, 2)
        doc.status = "finished"; doc.closed_by = frappe.session.user; doc.closure_type = "admin"
        doc.save(ignore_permissions=True); frappe.db.commit()
        return ok(break_id=doc.name, duration_seconds=duration, duration_formatted=_fmt(duration), message="Break force-closed by admin")
    except Exception as e:
        return fail(e)

@frappe.whitelist()
def get_my_active_break() -> dict | None:
    try:
        if frappe.session.user == "Guest": return None
        employee = employee_for_user()
        if not employee: return None
        active = frappe.db.get_value("Employee Break Log", {"employee": employee, "status": "active"},
                                     ["name", "start_time", "break_type", "notes", "extension_at_start"], as_dict=True)
        if active:
            active["duration_so_far"] = int(time_diff_in_seconds(now_datetime(), active["start_time"])); active["start_time"] = str(active["start_time"])
        return active
    except Exception:
        return None

@frappe.whitelist()
def get_all_active_breaks() -> list[dict]:
    try:
        if not has_any(BREAK_ADMIN_ROLES): return []
        rows = frappe.db.sql("""
            SELECT bl.name, bl.employee, bl.start_time, bl.break_type, bl.notes, bl.extension_at_start, bl.extension_was_online, e.employee_name
            FROM `tabEmployee Break Log` bl JOIN `tabEmployee` e ON bl.employee=e.name
            WHERE bl.status='active' ORDER BY bl.start_time DESC
        """, as_dict=True)
        for b in rows:
            b["duration_so_far"] = int(time_diff_in_seconds(now_datetime(), b.start_time)); b["duration_formatted"] = _fmt(b["duration_so_far"]); b["start_time"] = str(b.start_time)
        return rows
    except Exception:
        return []

@frappe.whitelist()
def get_breaks_report(date_from: str | None = None, date_to: str | None = None, employee: str | None = None) -> dict:
    try:
        if not has_any(BREAK_ADMIN_ROLES): return {"breaks": [], "totals_per_employee": [], "grand_total_count": 0, "grand_total_seconds": 0, "grand_total_formatted": "00:00:00"}
        date_from = date_from or today(); date_to = date_to or today()
        cond = "bl.break_date BETWEEN %s AND %s"; params = [date_from, date_to]
        if employee: cond += " AND bl.employee=%s"; params.append(employee)
        rows = frappe.db.sql(f"""
            SELECT bl.name, e.employee_name, bl.employee, bl.break_date, bl.start_time, bl.end_time,
                   bl.duration_seconds, bl.status, bl.closure_type, bl.closed_by, bl.extension_at_start, bl.break_type
            FROM `tabEmployee Break Log` bl JOIN `tabEmployee` e ON bl.employee=e.name
            WHERE {cond} ORDER BY bl.start_time DESC
        """, params, as_dict=True)
        totals = {}
        for b in rows:
            emp = b.employee_name; totals.setdefault(emp, {"employee_name": emp, "count": 0, "total_seconds": 0})
            totals[emp]["count"] += 1; totals[emp]["total_seconds"] += int(b.duration_seconds or 0)
            if b.start_time: b.start_time = str(b.start_time)
            if b.end_time: b.end_time = str(b.end_time)
            if b.break_date: b.break_date = str(b.break_date)
        tlist = list(totals.values())
        for t in tlist: t["total_formatted"] = _fmt(t["total_seconds"])
        grand = sum(t["total_seconds"] for t in tlist)
        return {"breaks": rows, "totals_per_employee": tlist, "grand_total_count": len(rows), "grand_total_seconds": grand, "grand_total_formatted": _fmt(grand)}
    except Exception as e:
        return {"breaks": [], "totals_per_employee": [], "grand_total_count": 0, "grand_total_seconds": 0, "grand_total_formatted": "00:00:00", "error": str(e)}

@frappe.whitelist()
def get_todays_breaks_summary() -> list[dict]:
    return get_breaks_report(date_from=today(), date_to=today()).get("breaks", [])
