"""Build/repair all Restaurant Ops DocTypes for clean v30 install.
This file intentionally uses one canonical schema that matches every API.
"""
import frappe

MODULE = "Restaurant Operations"


def _ensure_module():
    if not frappe.db.exists("Module Def", MODULE):
        frappe.get_doc({"doctype": "Module Def", "module_name": MODULE, "app_name": "restaurant_ops"}).insert(ignore_permissions=True)


def _field_map(fields):
    return {f.get("fieldname"): f for f in fields if f.get("fieldname")}


def ensure_doctype(name: str, spec: dict):
    """Create DocType if missing; if present, append missing fields/permissions safely."""
    spec = dict(spec)
    spec.update({"doctype": "DocType", "name": name, "module": MODULE, "custom": 0})
    if not frappe.db.exists("DocType", name):
        frappe.get_doc(spec).insert(ignore_permissions=True)
        print(f"   ✅ Created DocType: {name}")
        return

    doc = frappe.get_doc("DocType", name)
    changed = False
    existing = {d.fieldname for d in doc.fields if d.fieldname}
    for f in spec.get("fields", []):
        fn = f.get("fieldname")
        if fn and fn not in existing:
            doc.append("fields", f)
            existing.add(fn)
            changed = True
            print(f"      + field {name}.{fn}")
    # repair critical meta
    for k in ["autoname", "naming_rule", "issingle", "is_submittable", "sort_field", "sort_order", "track_changes", "allow_rename"]:
        if k in spec and getattr(doc, k, None) != spec[k]:
            try:
                setattr(doc, k, spec[k])
                changed = True
            except Exception:
                pass
    # make sure permissions exist; don't remove existing customer tweaks
    existing_perm = {(p.role, p.permlevel or 0) for p in doc.permissions}
    for p in spec.get("permissions", []):
        key = (p.get("role"), p.get("permlevel", 0))
        if key not in existing_perm:
            doc.append("permissions", p)
            existing_perm.add(key)
            changed = True
    if changed:
        doc.save(ignore_permissions=True)
        print(f"   🔧 Repaired DocType: {name}")
    else:
        print(f"   ⏭️  DocType OK: {name}")


def run():
    print("\n🏗️  Building Restaurant Ops v30 canonical DocTypes...\n")
    _ensure_module()
    for name, spec in DOCTYPES.items():
        ensure_doctype(name, spec)
    frappe.db.commit()
    print("\n✅ All DocTypes are ready.\n")


BASE_PERMS_ADMIN = [
    {"role": "System Manager", "read": 1, "write": 1, "create": 1, "delete": 1, "export": 1, "report": 1},
    {"role": "Call Center Admin", "read": 1, "write": 1, "create": 1, "delete": 1, "export": 1, "report": 1},
]

DOCTYPES = {
    "Break Type": {
        "autoname": "field:break_type", "naming_rule": "By fieldname",
        "sort_field": "modified", "sort_order": "DESC", "track_changes": 1,
        "fields": [
            {"fieldname": "break_type", "label": "Break Type", "fieldtype": "Data", "reqd": 1, "unique": 1, "in_list_view": 1},
            {"fieldname": "max_duration_minutes", "label": "Max Duration (minutes)", "fieldtype": "Int", "reqd": 1, "default": 30, "in_list_view": 1},
            {"fieldname": "color", "label": "Color", "fieldtype": "Color"},
            {"fieldname": "active", "label": "Active", "fieldtype": "Check", "default": 1, "in_list_view": 1},
            # Compatibility aliases from older builds
            {"fieldname": "duration_minutes", "label": "Duration (Minutes - Legacy)", "fieldtype": "Int", "default": 15, "hidden": 1},
            {"fieldname": "is_active", "label": "Is Active (Legacy)", "fieldtype": "Check", "default": 1, "hidden": 1},
        ],
        "permissions": BASE_PERMS_ADMIN + [
            {"role": "Break Admin", "read": 1, "write": 1, "create": 1, "delete": 1, "export": 1, "report": 1},
            {"role": "Restaurant Agent", "read": 1},
        ],
    },
    "SIP Extension": {
        "autoname": "field:extension_number", "naming_rule": "By fieldname",
        "sort_field": "extension_number", "sort_order": "ASC", "track_changes": 1,
        "fields": [
            {"fieldname": "extension_number", "label": "Extension Number", "fieldtype": "Data", "reqd": 1, "unique": 1, "in_list_view": 1},
            {"fieldname": "description", "label": "Description", "fieldtype": "Data", "in_list_view": 1},
            {"fieldname": "active", "label": "Active", "fieldtype": "Check", "default": 1, "in_list_view": 1},
            {"fieldname": "status", "label": "Status", "fieldtype": "Select", "options": "Free\nBusy\nLogged Out", "default": "Free", "in_list_view": 1},
            {"fieldname": "current_user", "label": "Current User", "fieldtype": "Link", "options": "User", "in_list_view": 1},
            {"fieldname": "notes", "label": "Notes", "fieldtype": "Small Text"},
        ],
        "permissions": BASE_PERMS_ADMIN + [
            {"role": "Break Admin", "read": 1, "write": 1, "create": 1, "export": 1, "report": 1},
            {"role": "Restaurant Agent", "read": 1},
        ],
    },
    "Extension Session": {
        "autoname": "format:EXT-SES-{YYYY}-{MM}-{DD}-{#####}", "naming_rule": "Expression",
        "sort_field": "creation", "sort_order": "DESC", "track_changes": 1,
        "fields": [
            {"fieldname": "user", "label": "User", "fieldtype": "Link", "options": "User", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "employee", "label": "Employee", "fieldtype": "Link", "options": "Employee", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "extension", "label": "Extension", "fieldtype": "Link", "options": "SIP Extension", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "col_1", "fieldtype": "Column Break"},
            {"fieldname": "session_status", "label": "Status", "fieldtype": "Select", "options": "active\nreleased\nforced_release", "default": "active", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "active", "label": "Active (Legacy)", "fieldtype": "Check", "default": 1, "hidden": 1},
            {"fieldname": "started_at", "label": "Started At", "fieldtype": "Datetime", "reqd": 1, "in_list_view": 1},
            {"fieldname": "released_at", "label": "Released At", "fieldtype": "Datetime"},
            {"fieldname": "ip_address", "label": "IP Address", "fieldtype": "Data"},
        ],
        "permissions": BASE_PERMS_ADMIN + [
            {"role": "Break Admin", "read": 1, "write": 1, "create": 1, "export": 1, "report": 1},
            {"role": "Restaurant Agent", "read": 1, "write": 1, "create": 1, "if_owner": 1},
        ],
    },
    "Employee Break Log": {
        "autoname": "naming_series:", "naming_rule": "By \"Naming Series\" field",
        "sort_field": "creation", "sort_order": "DESC", "track_changes": 1, "allow_rename": 1,
        "field_order": ["naming_series", "sec_1", "employee", "break_type", "break_date", "col_1", "status", "closed_by", "closure_type", "sec_2", "start_time", "end_time", "duration_seconds", "duration_minutes", "col_2", "extension_at_start", "extension_was_online", "notes"],
        "fields": [
            {"fieldname": "naming_series", "label": "Series", "fieldtype": "Select", "options": "BRK-.YYYY.-.MM.-.#####", "default": "BRK-.YYYY.-.MM.-.#####", "read_only": 1},
            {"fieldname": "sec_1", "fieldtype": "Section Break", "label": "Employee"},
            {"fieldname": "employee", "label": "Employee", "fieldtype": "Link", "options": "Employee", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "break_type", "label": "Break Type", "fieldtype": "Link", "options": "Break Type", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "break_date", "label": "Break Date", "fieldtype": "Date", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "col_1", "fieldtype": "Column Break"},
            {"fieldname": "status", "label": "Status", "fieldtype": "Select", "options": "active\nfinished\narchived\nActive\nCompleted\nCancelled", "default": "active", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "closed_by", "label": "Closed By", "fieldtype": "Link", "options": "User"},
            {"fieldname": "closure_type", "label": "Closure Type", "fieldtype": "Select", "options": "\nemployee\nadmin\ntimeout"},
            {"fieldname": "sec_2", "fieldtype": "Section Break", "label": "Timing"},
            {"fieldname": "start_time", "label": "Start Time", "fieldtype": "Datetime", "reqd": 1, "in_list_view": 1},
            {"fieldname": "end_time", "label": "End Time", "fieldtype": "Datetime", "in_list_view": 1},
            {"fieldname": "duration_seconds", "label": "Duration (seconds)", "fieldtype": "Int", "read_only": 1},
            {"fieldname": "duration_minutes", "label": "Duration (Min - Legacy)", "fieldtype": "Float", "read_only": 1, "hidden": 1},
            {"fieldname": "col_2", "fieldtype": "Column Break"},
            {"fieldname": "extension_at_start", "label": "Extension at Start", "fieldtype": "Link", "options": "SIP Extension"},
            {"fieldname": "extension_was_online", "label": "Extension was Online", "fieldtype": "Check", "default": 1},
            {"fieldname": "notes", "label": "Notes", "fieldtype": "Small Text"},
        ],
        "permissions": BASE_PERMS_ADMIN + [
            {"role": "Break Admin", "read": 1, "write": 1, "create": 1, "delete": 1, "export": 1, "report": 1},
            {"role": "Restaurant Agent", "read": 1, "write": 1, "create": 1, "if_owner": 1},
        ],
    },
    "Sales Item": {
        "autoname": "field:item_name", "naming_rule": "By fieldname",
        "sort_field": "item_name", "sort_order": "ASC", "track_changes": 1,
        "fields": [
            {"fieldname": "item_name", "label": "Item Name", "fieldtype": "Data", "reqd": 1, "unique": 1, "in_list_view": 1},
            {"fieldname": "item_category", "label": "Category", "fieldtype": "Select", "options": "\nFood\nBeverage\nDessert\nSandwiches\nMeals\nSides\nOther", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "active", "label": "Active", "fieldtype": "Check", "default": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "description", "label": "Description", "fieldtype": "Small Text"},
            {"fieldname": "category", "label": "Category (Legacy)", "fieldtype": "Data", "hidden": 1},
            {"fieldname": "is_active", "label": "Is Active (Legacy)", "fieldtype": "Check", "default": 1, "hidden": 1},
        ],
        "permissions": BASE_PERMS_ADMIN + [{"role": "Restaurant Agent", "read": 1}],
    },
    "Sales Entry": {
        "autoname": "naming_series:", "naming_rule": "By \"Naming Series\" field",
        "sort_field": "creation", "sort_order": "DESC", "track_changes": 1,
        "fields": [
            {"fieldname": "naming_series", "label": "Series", "fieldtype": "Select", "options": "SALE-.YYYY.-.MM.-.#####", "default": "SALE-.YYYY.-.MM.-.#####", "read_only": 1},
            {"fieldname": "sec_1", "fieldtype": "Section Break", "label": "Sale Details"},
            {"fieldname": "agent", "label": "Agent", "fieldtype": "Link", "options": "Employee", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "sale_date", "label": "Sale Date/Time", "fieldtype": "Datetime", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "col_1", "fieldtype": "Column Break"},
            {"fieldname": "item", "label": "Item", "fieldtype": "Link", "options": "Sales Item", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "quantity", "label": "Quantity", "fieldtype": "Int", "reqd": 1, "default": 1, "in_list_view": 1},
            {"fieldname": "sec_2", "fieldtype": "Section Break", "label": "Customer"},
            {"fieldname": "customer_name", "label": "Customer Name", "fieldtype": "Data", "in_list_view": 1},
            {"fieldname": "customer_phone", "label": "Customer Phone", "fieldtype": "Data", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "sec_3", "fieldtype": "Section Break", "label": "Notes"},
            {"fieldname": "notes", "label": "Notes", "fieldtype": "Small Text"},
        ],
        "permissions": BASE_PERMS_ADMIN + [{"role": "Restaurant Agent", "read": 1, "write": 1, "create": 1, "if_owner": 1}],
    },
    "Call Record": {
        "autoname": "field:uniqueid", "naming_rule": "By fieldname",
        "sort_field": "call_datetime", "sort_order": "DESC", "track_changes": 0,
        "fields": [
            {"fieldname": "sec_call", "fieldtype": "Section Break", "label": "Call Info"},
            {"fieldname": "uniqueid", "label": "Unique ID", "fieldtype": "Data", "reqd": 1, "unique": 1, "read_only": 1},
            {"fieldname": "call_datetime", "label": "Call DateTime", "fieldtype": "Datetime", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "customer_number", "label": "Customer Number", "fieldtype": "Data", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "extension", "label": "Extension", "fieldtype": "Data", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "col_call1", "fieldtype": "Column Break"},
            {"fieldname": "employee_at_time", "label": "Responsible Employee", "fieldtype": "Link", "options": "Employee", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "duration_seconds", "label": "Duration (sec)", "fieldtype": "Int"},
            {"fieldname": "billsec", "label": "Billsec", "fieldtype": "Int"},
            {"fieldname": "disposition", "label": "Disposition", "fieldtype": "Data", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "sec_analysis", "fieldtype": "Section Break", "label": "Smart Classification"},
            {"fieldname": "smart_category", "label": "Category", "fieldtype": "Select", "options": "\nanswered\nbusy\nfailed\nmissed_by_agent\ncustomer_hung_up\nunknown", "in_list_view": 1, "in_standard_filter": 1},
            {"fieldname": "was_answered", "label": "Was Answered", "fieldtype": "Check", "in_list_view": 1},
            {"fieldname": "col_call2", "fieldtype": "Column Break"},
            {"fieldname": "recording_file", "label": "Recording File Path", "fieldtype": "Data", "read_only": 1},
            {"fieldname": "recording_url", "label": "Recording URL", "fieldtype": "Data", "read_only": 1},
            {"fieldname": "sec_link", "fieldtype": "Section Break", "label": "Linked Complaint Section"},
            {"fieldname": "linked_complaint", "label": "Linked Complaint", "fieldtype": "Link", "options": "Call Center Complaint"},
            {"fieldname": "notes", "label": "Notes", "fieldtype": "Small Text"},
        ],
        "permissions": BASE_PERMS_ADMIN + [
            {"role": "Break Admin", "read": 1, "export": 1, "report": 1},
            {"role": "Complaint_Quality_User", "read": 1, "export": 1, "report": 1},
            {"role": "Restaurant Agent", "read": 1},
        ],
    },
    "Call Center Settings": {
        "issingle": 1, "sort_field": "modified", "sort_order": "DESC", "track_changes": 1,
        "fields": [
            {"fieldname": "sec_email", "fieldtype": "Section Break", "label": "Email Reports"},
            {"fieldname": "daily_report_enabled", "label": "Enable Daily Report", "fieldtype": "Check", "default": 1},
            {"fieldname": "center_manager_recipients", "label": "Center Manager Recipients", "fieldtype": "Small Text", "default": "el.alfy@roshdy.com"},
            {"fieldname": "upper_management_recipients", "label": "Upper Management Recipients", "fieldtype": "Small Text", "default": "admin@roshdy.com"},
            {"fieldname": "daily_report_recipients", "label": "Recipients Legacy", "fieldtype": "Small Text", "hidden": 1},
            {"fieldname": "col_email1", "fieldtype": "Column Break"},
            {"fieldname": "shift_start_hour", "label": "Shift Start Hour", "fieldtype": "Int", "default": 10},
            {"fieldname": "shift_end_hour", "label": "Shift End Hour", "fieldtype": "Int", "default": 5},
            {"fieldname": "sec_asterisk", "fieldtype": "Section Break", "label": "Asterisk / Elastix"},
            {"fieldname": "asterisk_host", "label": "Asterisk Host", "fieldtype": "Data", "default": "10.11.1.253"},
            {"fieldname": "asterisk_ami_port", "label": "AMI Port", "fieldtype": "Int", "default": 5038},
            {"fieldname": "col_asterisk", "fieldtype": "Column Break"},
            {"fieldname": "asterisk_recording_web_base", "label": "Recording Web Base URL", "fieldtype": "Data", "default": "http://10.11.1.253/monitor/"},
            {"fieldname": "sec_status", "fieldtype": "Section Break", "label": "Status"},
            {"fieldname": "last_call_sync", "label": "Last Call Sync", "fieldtype": "Datetime", "read_only": 1},
            {"fieldname": "last_call_sync_count", "label": "Last Sync Count", "fieldtype": "Int", "read_only": 1},
        ],
        "permissions": BASE_PERMS_ADMIN,
    },
    "Call Center Complaint": {
        "autoname": "naming_series:", "naming_rule": "By \"Naming Series\" field",
        "is_submittable": 0, "sort_field": "creation", "sort_order": "DESC", "track_changes": 1,
        "fields": [
            {"fieldname": "naming_series", "fieldtype": "Select", "label": "Complaint Number", "options": "COMP-.YYYY.-.#####\nCOMP-", "default": "COMP-.YYYY.-.#####", "hidden": 1, "permlevel": 0},
            {"fieldname": "basic_info_section", "fieldtype": "Section Break", "label": "1. Basic Info Section", "permlevel": 0},
            {"fieldname": "customer_name", "label": "Customer Name", "fieldtype": "Data", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1, "permlevel": 0},
            {"fieldname": "phone_number", "label": "Phone Number", "fieldtype": "Data", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1, "permlevel": 0},
            {"fieldname": "col_basic", "fieldtype": "Column Break", "permlevel": 0},
            {"fieldname": "complaint_source", "label": "Complaint Source", "fieldtype": "Select", "options": "Call\nWhatsApp\nFacebook\nOther", "default": "Call", "permlevel": 0},
            {"fieldname": "complaint_category", "label": "Complaint Category", "fieldtype": "Select", "options": "Service Quality\nDelay\nBehavior\nFood Quality\nDelivery\nOther", "reqd": 1, "in_list_view": 1, "in_standard_filter": 1, "permlevel": 0},
            {"fieldname": "complaint_priority", "label": "Priority", "fieldtype": "Select", "options": "Low\nMedium\nHigh\nUrgent", "default": "Medium", "in_standard_filter": 1, "permlevel": 0},
            {"fieldname": "opened_by_agent", "label": "Opened By Agent", "fieldtype": "Link", "options": "Employee", "read_only": 1, "in_standard_filter": 1, "permlevel": 0},
            {"fieldname": "complaint_details", "label": "Complaint Details", "fieldtype": "Small Text", "reqd": 1, "permlevel": 0},
            {"fieldname": "shift_and_timing_section", "fieldtype": "Section Break", "label": "2. Shift & Timing Section", "permlevel": 0},
            {"fieldname": "complaint_datetime", "label": "Complaint DateTime", "fieldtype": "Datetime", "reqd": 1, "in_list_view": 1, "permlevel": 0},
            {"fieldname": "shift", "label": "Shift", "fieldtype": "Select", "options": "Basic Shift\nMorning Shift\nEvening Shift\nNight Shift", "default": "Basic Shift", "permlevel": 0},
            {"fieldname": "col_shift", "fieldtype": "Column Break", "permlevel": 0},
            {"fieldname": "shift_leader", "label": "Shift Leader", "fieldtype": "Link", "options": "User", "permlevel": 0},
            {"fieldname": "quality_section_break", "fieldtype": "Section Break", "label": "3. Quality Review Section", "permlevel": 1},
            {"fieldname": "assigned_quality_inspector", "label": "Assigned Inspector", "fieldtype": "Link", "options": "User", "permlevel": 1},
            {"fieldname": "investigation_analysis", "label": "Investigation Analysis", "fieldtype": "Long Text", "permlevel": 1},
            {"fieldname": "corrective_action", "label": "Corrective Action", "fieldtype": "Small Text", "permlevel": 1},
            {"fieldname": "finance_section_break", "fieldtype": "Section Break", "label": "4. Financial Impact Section", "permlevel": 2},
            {"fieldname": "has_financial_impact", "label": "Has Financial Impact", "fieldtype": "Check", "default": 0, "permlevel": 2},
            {"fieldname": "col_fin", "fieldtype": "Column Break", "permlevel": 2},
            {"fieldname": "compensation_amount", "label": "Compensation Amount", "fieldtype": "Currency", "depends_on": "eval:doc.has_financial_impact==1", "permlevel": 2},
            {"fieldname": "finance_status", "label": "Finance Status", "fieldtype": "Select", "options": "\nUnder Review\nCompensated\nRejected", "depends_on": "eval:doc.has_financial_impact==1", "permlevel": 2},
            {"fieldname": "status_and_control_section", "fieldtype": "Section Break", "label": "5. Status & Control Section", "permlevel": 0},
            {"fieldname": "status", "label": "Status", "fieldtype": "Select", "options": "Draft\nOpen\nUnder Review\nClosed\nResolved", "default": "Draft", "in_list_view": 1, "in_standard_filter": 1, "permlevel": 0},
            {"fieldname": "closing_notes", "label": "Closing Notes", "fieldtype": "Small Text", "depends_on": "eval:doc.status=='Closed' || doc.status=='Resolved'", "permlevel": 0},
            {"fieldname": "col_stat", "fieldtype": "Column Break", "permlevel": 0},
            {"fieldname": "resolved_by", "label": "Resolved By", "fieldtype": "Link", "options": "User", "read_only": 1, "permlevel": 0},
            {"fieldname": "resolved_at", "label": "Resolved At", "fieldtype": "Datetime", "read_only": 1, "permlevel": 0},
            {"fieldname": "call_record_link", "label": "Linked Call Record", "fieldtype": "Link", "options": "Call Record", "permlevel": 0},
        ],
        "permissions": [
            {"role": "System Manager", "permlevel": 0, "read": 1, "write": 1, "create": 1, "delete": 1, "export": 1, "report": 1},
            {"role": "System Manager", "permlevel": 1, "read": 1, "write": 1},
            {"role": "System Manager", "permlevel": 2, "read": 1, "write": 1},
            {"role": "Call Center Admin", "permlevel": 0, "read": 1, "write": 1, "create": 1, "delete": 1, "export": 1, "report": 1},
            {"role": "Call Center Admin", "permlevel": 1, "read": 1, "write": 1},
            {"role": "Call Center Admin", "permlevel": 2, "read": 1, "write": 1},
            {"role": "Restaurant Agent", "permlevel": 0, "read": 1, "write": 1, "create": 1},
            {"role": "Complaint_Quality_User", "permlevel": 0, "read": 1},
            {"role": "Complaint_Quality_User", "permlevel": 1, "read": 1, "write": 1},
            {"role": "Complaint_Finance_User", "permlevel": 0, "read": 1},
            {"role": "Complaint_Finance_User", "permlevel": 2, "read": 1, "write": 1},
        ],
    },
}

if __name__ == "__main__":
    run()
