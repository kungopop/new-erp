import frappe

def run_full_setup():
    from restaurant_ops.scripts import create_roles, setup_employee_fields, build_all_doctypes, import_employees, seed_data
    print("\n🚀 Running Restaurant Ops v30 full setup...\n")
    create_roles.run()
    setup_employee_fields.run()
    build_all_doctypes.run()
    frappe.db.commit()
    import_employees.run()
    seed_data.run()
    frappe.db.commit()
    print("\n🎉 Restaurant Ops v30 setup complete.\n")
    return {"success": True}
