import frappe

BREAK_TYPES = [
    {"break_type": "Lunch", "max_duration_minutes": 30, "color": "#3498db"},
    {"break_type": "Prayer", "max_duration_minutes": 15, "color": "#2ecc71"},
    {"break_type": "Personal", "max_duration_minutes": 10, "color": "#e67e22"},
    {"break_type": "Emergency", "max_duration_minutes": 45, "color": "#e74c3c"},
]
SAMPLE_ITEMS = [
    {"item_name": "Chicken Meal", "item_category": "Food"},
    {"item_name": "Beef Meal", "item_category": "Food"},
    {"item_name": "Family Combo", "item_category": "Food"},
    {"item_name": "Pepsi 500ml", "item_category": "Beverage"},
    {"item_name": "Water 500ml", "item_category": "Beverage"},
    {"item_name": "Chocolate Cake", "item_category": "Dessert"},
]

def run():
    print("\n🌱 Seeding SIP extensions, break types, settings, and sales items...\n")
    created_ext = 0
    for num in range(1001, 1031):
        ext = str(num)
        if not frappe.db.exists("SIP Extension", ext):
            frappe.get_doc({"doctype": "SIP Extension", "extension_number": ext, "description": f"SIP Extension {ext}", "active": 1, "status": "Free"}).insert(ignore_permissions=True)
            created_ext += 1
    created_bt = 0
    for bt in BREAK_TYPES:
        if not frappe.db.exists("Break Type", bt["break_type"]):
            frappe.get_doc({"doctype": "Break Type", **bt, "duration_minutes": bt["max_duration_minutes"], "active": 1, "is_active": 1}).insert(ignore_permissions=True)
            created_bt += 1
    created_si = 0
    for it in SAMPLE_ITEMS:
        if not frappe.db.exists("Sales Item", it["item_name"]):
            frappe.get_doc({"doctype": "Sales Item", **it, "category": it["item_category"], "active": 1, "is_active": 1}).insert(ignore_permissions=True)
            created_si += 1
    settings = frappe.get_single("Call Center Settings")
    settings.daily_report_enabled = 1
    settings.center_manager_recipients = settings.center_manager_recipients or "el.alfy@roshdy.com"
    settings.upper_management_recipients = settings.upper_management_recipients or "admin@roshdy.com"
    settings.daily_report_recipients = settings.daily_report_recipients or "admin@roshdy.com, el.alfy@roshdy.com"
    settings.shift_start_hour = settings.shift_start_hour or 10
    settings.shift_end_hour = settings.shift_end_hour or 5
    settings.asterisk_host = settings.asterisk_host or frappe.conf.get("asterisk_host") or "10.11.1.253"
    settings.asterisk_ami_port = settings.asterisk_ami_port or int(frappe.conf.get("asterisk_ami_port") or 5038)
    settings.asterisk_recording_web_base = settings.asterisk_recording_web_base or "http://10.11.1.253/monitor/"
    settings.save(ignore_permissions=True)
    frappe.db.commit()
    print(f"   ✅ SIP={created_ext}, BreakTypes={created_bt}, SalesItems={created_si}, Settings=ready")
