import frappe

ROLES = [
    ("Restaurant Agent", "Regular agent — breaks, extension, complaints and sales"),
    ("Break Admin", "Can view and close employee breaks"),
    ("Call Center Admin", "Full call center administration"),
    ("Complaint_Quality_User", "Quality team complaint investigation level"),
    ("Complaint_Finance_User", "Finance team compensation settlement level"),
]

def run():
    print("\n👑 Creating Restaurant Ops custom roles...\n")
    for role, desc in ROLES:
        if not frappe.db.exists("Role", role):
            frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1, "is_custom": 1, "description": desc}).insert(ignore_permissions=True)
            print(f"   ✅ {role}")
        else:
            doc = frappe.get_doc("Role", role)
            changed = False
            if not doc.desk_access:
                doc.desk_access = 1; changed = True
            if changed:
                doc.save(ignore_permissions=True)
            print(f"   ⏭️  {role}")
    frappe.db.commit()
