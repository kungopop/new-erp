import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

CUSTOM_FIELDS = {
    "Employee": [
        {"fieldname": "restaurant_ops_section", "label": "Restaurant Ops", "fieldtype": "Section Break", "insert_after": "employee_number", "collapsible": 1},
        {"fieldname": "extension", "label": "SIP Extension", "fieldtype": "Data", "insert_after": "restaurant_ops_section"},
        {"fieldname": "extension_status", "label": "Extension Status", "fieldtype": "Select", "options": "\nonline\noffline\nunknown", "insert_after": "extension", "read_only": 1, "default": "unknown"},
        {"fieldname": "extension_column_break", "fieldtype": "Column Break", "insert_after": "extension_status"},
        {"fieldname": "last_seen_on_extension", "label": "Last Seen", "fieldtype": "Datetime", "insert_after": "extension_column_break", "read_only": 1},
        {"fieldname": "old_system_id", "label": "Old System ID", "fieldtype": "Data", "insert_after": "last_seen_on_extension", "read_only": 1},
    ]
}

def run():
    print("\n🏷️  Ensuring Employee custom fields...\n")
    create_custom_fields(CUSTOM_FIELDS, ignore_validate=True)
    frappe.db.commit()
    print("   ✅ Employee custom fields ready")
