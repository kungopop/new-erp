(function() {
  function checkAndRedirect() {
    var path = window.location.pathname || "";
    if ((path.startsWith("/app") && !path.includes("call-center-complaint")) || path.startsWith("/choose")) {
      if (typeof frappe !== "undefined" && frappe.session && frappe.session.user && frappe.session.user !== "Administrator") {
        var opts = { method: "POST", credentials: "same-origin" };
        if (frappe.csrf_token) opts.headers = { "X-Frappe-CSRF-Token": frappe.csrf_token };
        fetch("/api/method/restaurant_ops.api.login_redirect.get_user_redirect", opts)
          .then(function(r){ return r.json(); })
          .then(function(d){
            var target = d && d.message && d.message.redirect;
            if (target && target !== "/app" && !path.startsWith(target)) window.location.replace(target);
          }).catch(function(){});
        return true;
      }
    }
    return false;
  }
  var attempts = 0;
  var timer = setInterval(function(){ attempts++; if (checkAndRedirect() || attempts > 60) clearInterval(timer); }, 120);
  if (typeof frappe !== "undefined" && frappe.router) frappe.router.on("change", checkAndRedirect);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", checkAndRedirect); else checkAndRedirect();
})();
