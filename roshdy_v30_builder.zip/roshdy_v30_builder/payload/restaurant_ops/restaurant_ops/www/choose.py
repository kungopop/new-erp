from restaurant_ops.www.home import get_context
no_cache = 1
