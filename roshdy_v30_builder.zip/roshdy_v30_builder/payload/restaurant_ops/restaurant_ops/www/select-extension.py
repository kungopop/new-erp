import frappe
from restaurant_ops.www._context import protect
no_cache = 1

def get_context(context):
    user, roles, ok = protect(context, agent_allowed=True)
    context.current_ext = ""
    if ok:
        context.current_ext = frappe.db.get_value("Extension Session", {"user": user, "session_status": "active"}, "extension") or ""
