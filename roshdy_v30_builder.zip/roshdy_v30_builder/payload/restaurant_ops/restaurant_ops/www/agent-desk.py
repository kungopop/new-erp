import frappe
from restaurant_ops.www._context import protect
no_cache = 1

def get_context(context):
    user, roles, ok = protect(context, agent_allowed=True)
    context.my_extension = ""; context.needs_extension = 0
    if ok:
        ext = frappe.db.get_value("Extension Session", {"user": user, "session_status": "active"}, "extension")
        if ext: context.my_extension = ext
        else: context.needs_extension = 1; context.redirect_target = "/select-extension"
