import frappe
from restaurant_ops.www._context import protect, ADMIN_ROLES, QUALITY_ROLES
no_cache = 1

def get_context(context):
    user, roles, ok = protect(context, allowed_roles=ADMIN_ROLES | QUALITY_ROLES)
    context.active_breaks = context.open_complaints = context.today_complaints = context.today_calls = 0
    if ok:
        try:
            today = frappe.utils.today()
            context.active_breaks = frappe.db.count("Employee Break Log", {"status": "active"}) or 0
            context.open_complaints = frappe.db.count("Call Center Complaint", {"status": ["not in", ["Closed", "Resolved"]]}) or 0
            context.today_complaints = frappe.db.count("Call Center Complaint", {"resolved_at": [">=", f"{today} 00:00:00"]}) or 0
            context.today_calls = frappe.db.count("Call Record", {"call_datetime": [">=", f"{today} 00:00:00"]}) or 0
        except Exception: pass
