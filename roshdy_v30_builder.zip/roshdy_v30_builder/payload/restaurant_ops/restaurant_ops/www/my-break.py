from restaurant_ops.www._context import protect
no_cache = 1

def get_context(context):
    protect(context, agent_allowed=True)
