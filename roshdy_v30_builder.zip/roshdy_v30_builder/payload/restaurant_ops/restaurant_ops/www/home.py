from restaurant_ops.www._context import fill_common, route_for_user
no_cache = 1

def get_context(context):
    user, roles = fill_common(context)
    context.redirect_target = route_for_user(user, roles)
