import frappe

ADMIN_ROLES = {"Call Center Admin", "System Manager", "Break Admin", "Complaint_Finance_User"}
QUALITY_ROLES = {"Complaint_Quality_User", "Call Center Admin", "System Manager"}
AGENT_ROLE = "Restaurant Agent"

def fill_common(context, default_name="User"):
    user = frappe.session.user
    context.user_email = user or "Guest"
    context.is_guest = 1 if (not user or user == "Guest") else 0
    context.csrf_token = getattr(frappe.session, "csrf_token", "") or ""
    context.employee_name = default_name if context.is_guest else (frappe.db.get_value("Employee", {"user_id": user}, "employee_name") or user.split("@")[0])
    context.redirect_target = ""
    return user, frappe.get_roles(user) if user and user != "Guest" else []

def route_for_user(user, roles):
    if not user or user == "Guest": return "/login"
    if user == "Administrator": return "/app"
    if "Complaint_Quality_User" in roles and "Call Center Admin" not in roles and "System Manager" not in roles: return "/quality-desk"
    if any(r in ADMIN_ROLES for r in roles): return "/admin-desk"
    if AGENT_ROLE in roles:
        ext = frappe.db.get_value("Extension Session", {"user": user, "session_status": "active"}, "extension")
        return "/agent-desk" if ext else "/select-extension"
    return "/login?msg=no_role"

def protect(context, allowed_roles=None, agent_allowed=False, quality_allowed=False):
    user, roles = fill_common(context)
    if context.is_guest:
        context.redirect_target = "/login?redirect-to=" + frappe.local.request.path
        return user, roles, False
    if user == "Administrator": return user, roles, True
    allowed = set(allowed_roles or [])
    if agent_allowed: allowed.add(AGENT_ROLE)
    if quality_allowed: allowed |= QUALITY_ROLES
    ok = bool(set(roles) & allowed) if allowed else True
    if not ok:
        context.redirect_target = route_for_user(user, roles)
    return user, roles, ok
