from restaurant_ops.www._context import protect, ADMIN_ROLES, QUALITY_ROLES
no_cache = 1

def get_context(context):
    protect(context, allowed_roles=ADMIN_ROLES | QUALITY_ROLES)
