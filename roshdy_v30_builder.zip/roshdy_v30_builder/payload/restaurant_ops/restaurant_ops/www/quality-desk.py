import frappe
from restaurant_ops.www._context import protect, QUALITY_ROLES
no_cache = 1

def get_context(context):
    user, roles, ok = protect(context, allowed_roles=QUALITY_ROLES)
    context.total_comp = context.resolved_comp = context.open_comp = context.urgent_comp = 0
    if ok:
        try:
            context.total_comp = frappe.db.count("Call Center Complaint") or 0
            context.resolved_comp = frappe.db.count("Call Center Complaint", {"status": ["in", ["Closed", "Resolved"]]}) or 0
            context.open_comp = frappe.db.count("Call Center Complaint", {"status": ["in", ["Draft", "Open", "Under Review"]]}) or 0
            context.urgent_comp = frappe.db.count("Call Center Complaint", {"complaint_priority": ["in", ["High", "Urgent"]], "status": ["!=", "Resolved"]}) or 0
        except Exception: pass
