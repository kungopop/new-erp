from setuptools import setup, find_packages
setup(
    name='restaurant_ops',
    version='30.0.0',
    description='Roshdy Restaurant Operations and Contact Center for ERPNext v15',
    author='Roshdy IT',
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
)
