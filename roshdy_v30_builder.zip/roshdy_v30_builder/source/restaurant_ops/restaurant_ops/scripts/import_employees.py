import frappe
import csv
import os
from frappe.utils.password import update_password

CSV_PATH = "/tmp/roshdy_employees.csv"
DOMAIN = "roshdy.com"
COMPANY_NAME = "roshdy"
PASSWORD_PREFIX = "Roshdy@"
ADMIN_USERS = {"admin", "el.alfy", "mostafa"}
ADMIN_ROLES = ["Call Center Admin", "Break Admin", "System Manager", "Complaint_Quality_User", "Complaint_Finance_User"]
AGENT_ROLES = ["Restaurant Agent"]


def ensure_warehouse_type_transit():
    """ERPNext sometimes misses Warehouse Type 'Transit' before creating first Company.
    Normal Company insert triggers default warehouse creation and needs this link.
    """
    try:
        if frappe.db.exists("DocType", "Warehouse Type") and not frappe.db.exists("Warehouse Type", "Transit"):
            try:
                frappe.get_doc({"doctype": "Warehouse Type", "warehouse_type": "Transit"}).insert(ignore_permissions=True)
            except Exception:
                # Fallback for naming differences
                if not frappe.db.exists("Warehouse Type", "Transit"):
                    frappe.db.sql("""
                        INSERT INTO `tabWarehouse Type`
                        (name, creation, modified, modified_by, owner, docstatus, idx, warehouse_type)
                        VALUES ('Transit', NOW(), NOW(), 'Administrator', 'Administrator', 0, 0, 'Transit')
                    """)
            frappe.db.commit()
            print("   ✅ Warehouse Type Transit ready")
    except Exception as e:
        print(f"   ⚠️ Could not precreate Warehouse Type Transit normally: {e}")


def ensure_company():
    ensure_warehouse_type_transit()

    if frappe.db.exists("Company", COMPANY_NAME):
        return COMPANY_NAME

    # If any company already exists, use it and don't fight ERPNext setup.
    existing = frappe.db.get_value("Company", {}, "name")
    if existing:
        print(f"   ⏭️  Using existing Company: {existing}")
        return existing

    try:
        frappe.get_doc({
            "doctype": "Company",
            "company_name": COMPANY_NAME,
            "abbr": "RSH",
            "default_currency": "EGP",
            "country": "Egypt",
        }).insert(ignore_permissions=True)
        frappe.db.commit()
        print(f"   ✅ Company created normally: {COMPANY_NAME}")
        return COMPANY_NAME
    except Exception as e:
        print(f"   ⚠️ Normal Company creation failed: {e}")
        print("   🛠️ Emergency minimal Company SQL insert for Employee links...")
        try:
            frappe.db.rollback()
        except Exception:
            pass
        if not frappe.db.exists("Company", COMPANY_NAME):
            frappe.db.sql("""
                INSERT INTO `tabCompany`
                (name, creation, modified, modified_by, owner, docstatus, idx,
                 company_name, abbr, default_currency, country)
                VALUES (%s, NOW(), NOW(), 'Administrator', 'Administrator', 0, 0,
                        %s, %s, %s, %s)
            """, (COMPANY_NAME, COMPANY_NAME, "RSH", "EGP", "Egypt"))
            frappe.db.commit()
        print(f"   ✅ Emergency Company row ready: {COMPANY_NAME}")
        return COMPANY_NAME


def _split_name(full_name: str):
    parts = (full_name or "User").strip().split(" ", 1)
    return parts[0], parts[1] if len(parts) > 1 else parts[0]


def _ensure_role(user_doc, role):
    if frappe.db.exists("Role", role) and role not in [r.role for r in user_doc.roles]:
        user_doc.append("roles", {"role": role})


def import_one(row, company_name):
    email_user = row.get("email_username", "").strip().lower()
    if not email_user:
        return "skipped"

    email = f"{email_user}@{DOMAIN}"
    full_name = row.get("full_name", email_user).strip() or email_user
    password = f"{PASSWORD_PREFIX}{row.get('password', '123456')}"
    first, last = _split_name(full_name)
    is_admin = email_user in ADMIN_USERS

    if frappe.db.exists("User", email):
        user = frappe.get_doc("User", email)
        created = False
    else:
        user = frappe.get_doc({
            "doctype": "User",
            "email": email,
            "first_name": first,
            "last_name": last,
            "enabled": 1,
            "user_type": "System User",
            "send_welcome_email": 0,
            "language": "en",
            "time_zone": "Africa/Cairo",
        }).insert(ignore_permissions=True)
        created = True

    update_password(user.name, password)
    roles_to_add = ADMIN_ROLES if is_admin else AGENT_ROLES
    for role in roles_to_add:
        _ensure_role(user, role)
    if is_admin:
        user.roles = [r for r in user.roles if r.role != "Restaurant Agent"]
    user.enabled = 1
    user.save(ignore_permissions=True)

    emp_name = frappe.db.get_value("Employee", {"user_id": email}, "name")
    if not emp_name:
        emp = frappe.get_doc({
            "doctype": "Employee",
            "employee_name": full_name,
            "first_name": first,
            "last_name": last or first,
            "gender": "Male",
            "date_of_birth": "1995-01-01",
            "date_of_joining": frappe.utils.today(),
            "status": "Active",
            "company": company_name,
            "user_id": email,
            "personal_email": email,
            "old_system_id": row.get("old_id", ""),
        }).insert(ignore_permissions=True)
        emp_name = emp.name

    return "created" if created else "updated"


def run():
    print("\n👥 Importing Roshdy users/employees...\n")
    company_name = ensure_company()

    if not os.path.exists(CSV_PATH):
        print(f"   ⚠️ CSV not found: {CSV_PATH}")
        return

    stats = {"created": 0, "updated": 0, "skipped": 0, "errors": 0}
    with open(CSV_PATH, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                stats[import_one(row, company_name)] += 1
            except Exception as e:
                stats["errors"] += 1
                print(f"   ❌ {row.get('email_username')}: {e}")

    frappe.db.commit()
    print(f"   ✅ Users created={stats['created']} updated={stats['updated']} skipped={stats['skipped']} errors={stats['errors']}")
