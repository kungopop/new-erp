ROSHDY SYSTEM v30 CLEAN INSTALL
================================

Main deliverable:
  ROSHDY_SYSTEM_v30_CLEAN_INSTALL_ONE_SHOT.sh

Latest update in this build:
  - Global live waiting-calls counter appears on every operational page.
  - Employee break page now shows break types as big buttons, not a dropdown.
  - Elastix/Asterisk connection is stress-checked from the host before install and through Frappe after install.
  - Uses the proven v23 Elastix connection pattern: primary CDR user + fallback user, AMI socket reuse/shutdown, QueueStatus + queue show.

Run on a fresh Ubuntu server as root:
  sudo bash ROSHDY_SYSTEM_v30_CLEAN_INSTALL_ONE_SHOT.sh

Optional overrides:
  SERVER_IP=10.11.1.66 SITE_NAME=crm.local sudo -E bash ROSHDY_SYSTEM_v30_CLEAN_INSTALL_ONE_SHOT.sh
  ELASTIX_STRESS_ATTEMPTS=20 sudo -E bash ROSHDY_SYSTEM_v30_CLEAN_INSTALL_ONE_SHOT.sh
  REQUIRE_ELASTIX_OK=1 sudo -E bash ROSHDY_SYSTEM_v30_CLEAN_INSTALL_ONE_SHOT.sh
  NUKE_EXISTING=0 sudo -E bash ROSHDY_SYSTEM_v30_CLEAN_INSTALL_ONE_SHOT.sh

Default login after install:
  URL: http://SERVER_IP/login
  ERP Administrator: Administrator / Admin123!
  Admin: el.alfy@roshdy.com / Roshdy@1102
  Agent example: omar.elboghdady@roshdy.com / Roshdy@1122
