============================================================
Roshdy Elastix/Asterisk Log Inspector - READ ONLY
Generated: 2026-08-12 12:14:04
Host: localhost.localdomain
User: root
Log dir: /var/log/asterisk
Output dir: /root/ELASTIX_LOG_INSPECT_20260812_121404
Shift: 2026-08-12 10:00:00 -> 2026-08-13 05:00:00
Shift epoch: 1786518000 -> 1786586400
TAIL_LINES for full/freepbx analysis: 200000
SCAN_OLD: 0
NOTE: This script does NOT delete, truncate, compress, rotate, or edit Asterisk logs.
============================================================
